# Maze Lab — an advanced pygame pathfinding playground

Ten pathfinding algorithms, ten maze generators, weighted terrain, live editing,
dynamic replanning and a built-in benchmark bench. Pure Python + pygame, no numpy,
no assets — every pixel is drawn at runtime.

![Maze Lab](docs/preview.png)

`docs/demo.gif` shows A*, Jump Point Search, Theta* and a D* Lite agent replanning
around obstacles that appear while it walks.

---

## Quick start

```bash
pip install -r requirements.txt      # pygame >= 2.5
python main.py
```

Useful launch flags:

```bash
python main.py --maze cave -d -w          # 8-way cave with weighted terrain
python main.py --algo jps --size 81 -d    # big grid, Jump Point Search
python main.py --algo dstar --instant     # solve without animation
python main.py --benchmark --maze rooms --size 61 -d   # headless table, no window
python main.py --selftest                 # correctness suite
python main.py --demo                     # re-render docs/*.png and docs/demo.gif
```

---

## The algorithms

| # | Algorithm | Optimal | Weights | What makes it interesting |
|---|-----------|---------|---------|---------------------------|
| 1 | **Breadth-First Search** | uniform only | no | FIFO wavefront, the baseline |
| 2 | **Depth-First Search** | no | no | LIFO plunge — fast, wildly suboptimal |
| 3 | **Dijkstra / Uniform Cost** | yes | yes | ground truth for every optimality test |
| 4 | **A\*** | yes | yes | consistent heuristic, low-h tie-breaking |
| 5 | **Weighted A\*** | ≤ ε·optimal | yes | `f = g + ε·h`, tunable ε from 1.0 to 4.0 |
| 6 | **Bidirectional A\*** | yes | yes | two front-to-end waves, provably optimal stopping rule |
| 7 | **Jump Point Search** | yes | no | JPS8 (8-way) + JPS4 (4-way), online symmetry breaking |
| 8 | **Theta\*** | any-angle | approx | line-of-sight parent shortcuts → straight segments |
| 9 | **D\* Lite** | yes | yes | incremental replanning while the world changes |
| 10 | **Ant Colony Optimisation** | no | yes | pheromone metaheuristic, watch the colony converge |

### Details worth knowing

**Jump Point Search** never queues symmetric corridor cells — it *jumps* along a
direction until it hits the goal or a *forced neighbour* (an obstacle corner that
breaks path symmetry). Two variants ship here:

* **JPS8** — the classic Harabor & Grastien rules, 8-connected, no corner cutting.
* **JPS4** — the original pruning rules are **not sound on 4-connected grids**
  (in an empty 4-way room a straight-only jump can never turn, so the goal is
  unreachable). This implements the horizontal-first canonical ordering from
  Baum's 2025 paper: horizontal moves are never pruned, vertical runs are
  compressed into jumps that stop at obstacle corners. The app picks the right
  variant automatically from the movement mode.

**Bidirectional A\*** runs a forward wave from the start and a backward wave from
the goal, both with front-to-end heuristics, and stops when
`μ ≤ min(top_f, top_b)` — provably optimal for consistent heuristics. The backward
wave uses *reversed* edge costs, which matters because terrain cost is directional
(entering a mud cell costs more than leaving it). Honest caveat: on a tight maze
with a strong heuristic it often expands **more** nodes than plain A\* — the two
waves each have to prove optimality. It shines with weak heuristics and open maps.
Try it with the heuristic set to `Zero`.

**Theta\*** propagates parents through line-of-sight checks (supercover
rasterisation, corner cutting rejected), so the result is a handful of straight
segments instead of a staircase. On weighted terrain the segment cost is
`length × mean terrain weight`, which is an approximation — it is near-optimal in
the continuous plane, not provably optimal on mud.

**D\* Lite** plans backwards from the goal and keeps `g` / `rhs` values plus a
keyed priority queue with the `km` heuristic offset. Turn on **Dynamic obstacles**
and walls appear (red flash) and vanish (green flash) around the agent while it
walks; each repair touches only the affected part of the search tree instead of
restarting. The telemetry panel shows the expansion count of the last repair.

**Ant Colony** is deliberately the odd one out: 24 ants per iteration walk a
pheromone × heuristic roulette wheel, backtrack out of dead ends, deposit on
success, and the trail evaporates each round with elitist reinforcement of the
best route. The purple overlay is pheromone density.

---

## Controls

| Input | Action |
|-------|--------|
| `Space` | run / pause |
| `N` | single expansion step |
| `R` | reset the search (keeps the maze) |
| `G` / `C` | generate a new maze / clear to an empty arena |
| `B` | benchmark all ten algorithms on the current maze |
| `Tab` / `Shift+Tab` | next / previous algorithm |
| `D` | toggle 4-way ↔ 8-way movement (never cuts corners) |
| `T` | toggle weighted terrain |
| `H` | toggle the g-cost heatmap (instead of expansion order) |
| `O` | toggle dynamic obstacles (auto-selects D* Lite) |
| `S` | save a screenshot to `screenshots/` |
| `[` `]` | cycle the maze generator |
| `+` / `-` | animation speed (100% = instant) |
| `1`–`5` | tool: wall, erase, mud, start, goal |
| left-drag | paint with the current tool |
| right-drag | erase |

Everything is also clickable in the right-hand panel. Sliders: grid size,
animation speed, Weighted A* ε. Choices: generator, heuristic
(auto / octile / manhattan / euclidean / chebyshev / zero).

## Maze generators

Recursive backtracker, randomised Prim, randomised Kruskal, recursive division,
braided maze (dead ends removed → lots of loops), cellular-automata cave, BSP rooms
with corridors, weighted noise terrain, random obstacle field, empty arena.
Every generator guarantees the start and goal are connected. Weighted terrain is
smoothed value noise (four octaves) mapped to a 1×–9× traversal cost.

---

## Benchmarks

Real output from `python main.py --benchmark`, same maze for every algorithm.

**61×41 BSP rooms, 8-way, uniform cost**

| Algorithm | Expansions | Jump scans | Path cost | Waypoints | ms |
|---|---:|---:|---:|---:|---:|
| Jump Point Search | **36** | 843 | 98.00 | 99 | 1.6 |
| D* Lite | 134 | 0 | 98.00 | 99 | 1.8 |
| A* | 475 | 0 | 98.00 | 99 | 3.5 |
| Weighted A* (ε=1.5) | 499 | 0 | 98.00 | 99 | 3.7 |
| Bidirectional A* | 509 | 0 | 98.00 | 99 | 4.0 |
| Theta* | 527 | 4173 | 98.00 | **5** | 14.9 |
| BFS / Dijkstra | 906 | 0 | 98.00 | 99 | 6.0 |
| Ant Colony | 202,323 | 0 | 112.73 | 110 | 670 |

**61×41 perfect maze, 4-way, uniform cost** — JPS4 561 expansions vs A* 915,
identical 586.00 cost.

Expansions are the honest work metric; the millisecond column includes the
overhead of yielding visualisation events, so it is indicative rather than a
tight microbenchmark. Press `B` in the app for the same table as an overlay.

---

## Correctness

```bash
python main.py --selftest
```

The suite checks, over randomized mazes of every generator, both connectivities
and with/without terrain:

* A*, Bidirectional A*, Dijkstra and D* Lite all return **exactly** Dijkstra's cost;
* the reported cost equals the actual walkable cost of the returned path;
* JPS8/JPS4 match A* on uniform grids and never expand more than Dijkstra;
* Weighted A* stays inside its ε bound;
* every Theta* segment has genuine line of sight and the path is never longer
  than the grid-optimal one;
* DFS and ACO only make legal moves;
* all eight exact solvers correctly report "no path" on a severed map;
* the D* Lite agent reaches the goal in a world that mutates mid-walk.

A 640-case randomized stress run (160 grids × 4 solvers) passes with zero
mismatches.

---

## Project layout

```
main.py                     CLI entry point (app / benchmark / selftest / demo)
demo.py                     headless renderer for the README images and GIF
maze_lab/
  grid.py                   flat grid, cached neighbours, terrain, supercover LOS
  heuristics.py             octile / manhattan / euclidean / chebyshev / zero
  mazegen.py                10 generators + value-noise terrain
  ui.py                     theme, fonts, buttons, sliders, choices
  app.py                    visualiser, editor, telemetry, benchmark overlay
  algorithms/
    base.py                 Event / Options / Stats / registry
    classic.py              BFS, DFS, Dijkstra
    astar.py                A*, Weighted A*, Bidirectional A*, Theta*
    jps.py                  JPS8 + JPS4
    dstar.py                D* Lite core + dynamic-world agent demo
    aco.py                  Ant Colony Optimisation
tests/test_solvers.py       optimality and replanning tests
```

Every algorithm is a **generator** that yields `Event` objects
(`expand`, `frontier`, `scan`, `path`, `info`, `agent`, `wall`, `pheromone`).
The renderer just consumes events, so animation speed, stepping and headless
benchmarking all use the exact same code path. Adding an algorithm is ~40 lines:

```python
class MySolver(Algorithm):
    key, name, tag = "mine", "My Solver", "experimental"
    blurb = "One line shown in the sidebar."

    def search(self, grid, opts):
        ...
        yield Event("expand", node, value=g)
        yield Event("path", path=tuple(path), value=cost)

register(MySolver())        # then add "mine" to ORDER
```

## References

* Harabor & Grastien, *Online Graph Pruning for Pathfinding on Grid Maps* (AAAI 2011) — JPS8
* Baum, *Jump Point Search Pathfinding in 4-connected Grids* (arXiv:2501.14816, 2025) — JPS4
* Nash et al., *Theta\*: Any-Angle Path Planning on Grids* (AAAI 2007)
* Koenig & Likhachev, *D\* Lite* (AAAI 2002)
* Pohl / Kwa — bidirectional heuristic search and its stopping condition
* Dorigo & Stützle — Ant Colony Optimisation
