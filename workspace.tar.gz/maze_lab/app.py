"""Maze Lab - the pygame application: visualiser, editor and benchmark bench."""
from __future__ import annotations

import math
import os
import random
import time
from datetime import datetime

import pygame

from . import mazegen
from .algorithms import ORDER, REGISTRY, Options, Stats
from .grid import INF, Grid
from .heuristics import DESCRIPTIONS, HEURISTICS, heuristic_for
from .ui import (ACCENT, BG, BORDER, CYAN, DIM, FLOOR, GOLD, GREEN, PANEL, PANEL_HI,
                 PURPLE, RED, TEXT, WALL, WALL_EDGE, Button, Choice, Fonts, Slider,
                 make_palette, panel, text, wrap)

SIDEBAR_W = 380
TOPBAR_H = 44
STATUS_H = 104
TOOLS = [("wall", "Wall", "1"), ("erase", "Erase", "2"), ("terrain", "Mud", "3"),
         ("start", "Start", "4"), ("goal", "Goal", "5")]
SPEED_STEPS = "instant"


class App:
    def __init__(self, size=(1400, 880), headless: bool = False, seed: int | None = None):
        pygame.init()
        pygame.display.set_caption("Maze Lab - advanced pathfinding playground")
        self.headless = headless
        self.screen = pygame.display.set_mode(size)
        self.W, self.H = size
        self.fonts = Fonts()
        self.clock = pygame.time.Clock()
        self.palette = make_palette()
        self.rng = random.Random(seed if seed is not None else 20261121)

        # ------------------------------------------------------------- state
        self.grid = Grid(41, 31, diagonal=False)
        self.algo_key = "astar"
        self.gen_kind = "braid"
        self.weighted = False
        self.heuristic = "auto"
        self.epsilon = 1.5
        self.speed = 34
        self.dynamic = False
        self.heatmap = False
        self.tool = "wall"
        self.state = "idle"
        self.iterator = None
        self.stats = Stats()
        self.message = ""
        self.message_until = 0.0
        self.compare_results = None
        self.snapshot: Grid | None = None
        self.running = True
        self.fps = 0.0
        self.time_acc = 0.0

        self.order: list[int] = []
        self.gval: list[float] = []
        self.frontier: set[int] = set()
        self.pheromone: dict[int, float] = {}
        self.path: list[int] = []
        self.path_progress = 0.0
        self.agent = -1
        self.replans = 0
        self.last_repair = ""

        self.painting = False
        self.paint_button = 1
        self.paint_last: int | None = None
        self.mouse = (0, 0)
        self.hover_cell = -1

        self.grid_area = pygame.Rect(0, TOPBAR_H, self.W - SIDEBAR_W,
                                     self.H - TOPBAR_H - STATUS_H)
        self.statusbar = pygame.Rect(0, self.H - STATUS_H, self.W - SIDEBAR_W, STATUS_H)
        self.sidebar = pygame.Rect(self.W - SIDEBAR_W, 0, SIDEBAR_W, self.H)
        self.base = pygame.Surface((1, 1))
        self.overlay = pygame.Surface((1, 1), pygame.SRCALPHA)
        self.base_dirty = True
        self.cell = 20
        self.origin = (0, 0)

        self._build_ui()
        self.new_maze()

    # ===================================================================== UI
    def _build_ui(self):
        f = self.fonts
        x = self.sidebar.x + 14
        w = SIDEBAR_W - 28
        self.widgets = []
        self.algo_buttons = {}
        y = 32
        for key in ORDER:
            algo = REGISTRY[key]
            b = Button((x, y, w, 26), algo.name,
                       lambda app, k=key: app.select_algorithm(k), style="ghost")
            b.algo_key = key
            self.algo_buttons[key] = b
            self.widgets.append(b)
            y += 29
        self.blurb_y = y + 4
        y += 54
        self.maze_head_y = y
        y += 18
        self.gen_choice = Choice((x, y, w, 36), "generator", list(mazegen.GENERATORS),
                                 [mazegen.GEN_LABELS[k] for k in mazegen.GENERATORS],
                                 mazegen.GENERATORS.index(self.gen_kind),
                                 lambda app, v: setattr(app, "gen_kind", v))
        self.widgets.append(self.gen_choice)
        y += 42
        self.size_slider = Slider((x, y, w, 32), "Grid size", 15, 101, 41,
                                  lambda app, v: app.set_size(int(v)), fmt="{:.0f} cells", step=2)
        self.widgets.append(self.size_slider)
        y += 38
        half = (w - 8) // 2
        self.widgets.append(Button((x, y, half, 30), "Generate", lambda a: a.new_maze(),
                                   style="primary", key_hint="G"))
        self.widgets.append(Button((x + half + 8, y, half, 30), "Clear",
                                   lambda a: a.clear_maze(), key_hint="C"))
        y += 36
        self.diag_btn = Button((x, y, half, 26), "8-way moves", lambda a: a.toggle_diagonal(),
                               toggle=True, key_hint="D")
        self.weight_btn = Button((x + half + 8, y, half, 26), "Weighted terrain",
                                 lambda a: a.toggle_terrain(), toggle=True)
        self.widgets += [self.diag_btn, self.weight_btn]
        y += 36
        self.search_head_y = y
        y += 18
        self.heur_choice = Choice((x, y, w, 36), "heuristic", list(HEURISTICS),
                                  [h.capitalize() for h in HEURISTICS], 0,
                                  lambda app, v: app.set_heuristic(v))
        self.widgets.append(self.heur_choice)
        y += 42
        self.speed_slider = Slider((x, y, w, 32), "Animation speed", 0, 100, self.speed,
                                   lambda app, v: setattr(app, "speed", int(v)),
                                   fmt="{:.0f}%")
        self.widgets.append(self.speed_slider)
        y += 38
        self.eps_slider = Slider((x, y, w, 32), "Weighted A* epsilon", 1.0, 4.0, self.epsilon,
                                 lambda app, v: app.set_epsilon(v), fmt="{:.2f}x", step=0.05)
        self.widgets.append(self.eps_slider)
        y += 38
        self.dyn_btn = Button((x, y, half, 26), "Dynamic obstacles", lambda a: a.toggle_dynamic(),
                              toggle=True)
        self.heat_btn = Button((x + half + 8, y, half, 26), "g-cost heatmap",
                               lambda a: a.toggle_heatmap(), toggle=True)
        self.widgets += [self.dyn_btn, self.heat_btn]
        y += 36
        self.run_btn = Button((x, y, w, 36), "RUN", lambda a: a.toggle_run(), style="primary",
                              key_hint="Space")
        self.widgets.append(self.run_btn)
        y += 42
        third = (w - 16) // 3
        self.widgets.append(Button((x, y, third, 28), "Step", lambda a: a.step_once(), key_hint="N"))
        self.widgets.append(Button((x + third + 8, y, third, 28), "Reset",
                                   lambda a: a.reset_search(), key_hint="R"))
        self.widgets.append(Button((x + 2 * (third + 8), y, third, 28), "Save PNG",
                                   lambda a: a.save_screenshot(), key_hint="S"))
        y += 34
        self.widgets.append(Button((x, y, w, 30), "BENCHMARK ALL 10 ALGORITHMS",
                                   lambda a: a.benchmark(), key_hint="B"))
        y += 36
        self.hint_y = y

        # toolbar
        self.tool_buttons = {}
        tx = 190
        for key, label, hint in TOOLS:
            b = Button((tx, 8, 92, 28), f"{label}", lambda app, k=key: app.set_tool(k),
                       style="ghost", key_hint=hint)
            b.tool_key = key
            self.tool_buttons[key] = b
            self.widgets.append(b)
            tx += 98
        self.set_tool("wall")

    # --------------------------------------------------------------- geometry
    def _layout_grid(self):
        g = self.grid
        avail_w = self.grid_area.w - 36
        avail_h = self.grid_area.h - 36
        self.cell = max(4, min(avail_w // g.cols, avail_h // g.rows))
        gw, gh = self.cell * g.cols, self.cell * g.rows
        self.origin = (self.grid_area.x + (self.grid_area.w - gw) // 2,
                       self.grid_area.y + (self.grid_area.h - gh) // 2)
        self.base = pygame.Surface((gw, gh))
        self.overlay = pygame.Surface((gw, gh), pygame.SRCALPHA)
        self.base_dirty = True

    def cell_rect(self, i: int) -> pygame.Rect:
        x, y = self.grid.pos(i)
        return pygame.Rect(x * self.cell, y * self.cell, self.cell, self.cell)

    def cell_center(self, i: int) -> tuple[int, int]:
        x, y = self.grid.pos(i)
        return (self.origin[0] + x * self.cell + self.cell // 2,
                self.origin[1] + y * self.cell + self.cell // 2)

    def cell_at(self, pos) -> int:
        gx = pos[0] - self.origin[0]
        gy = pos[1] - self.origin[1]
        if gx < 0 or gy < 0:
            return -1
        x, y = gx // self.cell, gy // self.cell
        if not self.grid.inside(x, y):
            return -1
        return self.grid.idx(x, y)

    # ================================================================== actions
    def say(self, msg: str, seconds: float = 4.0):
        self.message = msg
        self.message_until = time.time() + seconds

    def new_maze(self):
        self.snapshot = None
        mazegen.generate(self.grid, self.gen_kind, self.rng, weighted=self.weighted)
        self._layout_grid()
        self.reset_search(restore=False)
        self.say(f"{mazegen.GEN_LABELS[self.gen_kind]} - {self.grid.cols}x{self.grid.rows}")

    def clear_maze(self):
        self.snapshot = None
        self.grid.clear(keep_border=True)
        self.grid.ensure_solvable()
        self.reset_search(restore=False)
        self.base_dirty = True
        self.say("Empty arena - draw your own walls")

    def set_size(self, v: int):
        self.snapshot = None
        rows = max(11, int(v * self.grid.rows / max(1, self.grid.cols)) | 1)
        self.grid.resize(v, rows)
        self.new_maze()

    def select_algorithm(self, key: str):
        self.algo_key = key
        for k, b in self.algo_buttons.items():
            b.active = (k == key)
        self.reset_search()
        algo = REGISTRY[key]
        self.say(f"{algo.name} - {algo.tag}")

    def set_tool(self, key: str):
        self.tool = key
        for k, b in self.tool_buttons.items():
            b.active = (k == key)

    def set_heuristic(self, v: str):
        self.heuristic = v
        self.reset_search()
        self.say(DESCRIPTIONS[v], 5)

    def set_epsilon(self, v: float):
        self.epsilon = round(v, 2)
        if self.algo_key == "wastar":
            self.reset_search()

    def toggle_diagonal(self):
        self.grid.diagonal = self.diag_btn.active
        self.grid.invalidate()
        self.base_dirty = True
        self.reset_search()
        self.say("8-way movement (no corner cutting)" if self.grid.diagonal else "4-way movement")

    def toggle_terrain(self):
        self.weighted = self.weight_btn.active
        if self.weighted:
            mazegen.apply_terrain(self.grid, self.rng)
            self.grid.weight[self.grid.start] = 1.0
            self.grid.weight[self.grid.goal] = 1.0
            self.grid.invalidate()
        else:
            self.grid.weight = [1.0] * self.grid.size
            self.grid.invalidate()
        self.base_dirty = True
        self.reset_search()
        self.say("Weighted terrain: mud costs up to 9x per step" if self.weighted
                 else "Uniform terrain: every step costs 1")

    def toggle_dynamic(self):
        self.dynamic = self.dyn_btn.active
        if self.dynamic and self.algo_key != "dstar":
            self.select_algorithm("dstar")
            self.say("Dynamic obstacles need an incremental planner - switched to D* Lite", 5)
        else:
            self.say("Dynamic obstacles ON - walls will appear while the agent walks"
                     if self.dynamic else "Dynamic obstacles OFF")
        self.reset_search()

    def toggle_heatmap(self):
        self.heatmap = self.heat_btn.active
        self.repaint_overlay()

    def reset_search(self, restore: bool = True):
        if restore and self.snapshot is not None:
            self.grid.walls = bytearray(self.snapshot.walls)
            self.grid.weight = list(self.snapshot.weight)
            self.grid.start, self.grid.goal = self.snapshot.start, self.snapshot.goal
            self.grid.invalidate()
            self.snapshot = None
            self.base_dirty = True
        self.iterator = None
        self.state = "idle"
        self.stats.reset()
        n = self.grid.size
        self.order = [-1] * n
        self.gval = [INF] * n
        self.frontier.clear()
        self.pheromone.clear()
        self.path = []
        self.path_progress = 0.0
        self.agent = -1
        self.replans = 0
        self.last_repair = ""
        if self.overlay.get_size() != (self.cell * self.grid.cols, self.cell * self.grid.rows):
            self._layout_grid()
        self.overlay.fill((0, 0, 0, 0))

    def toggle_run(self):
        if self.state == "running":
            self.state = "paused"
            return
        if self.state == "paused" and self.iterator is not None:
            self.state = "running"
            return
        self.start_search()

    def start_search(self):
        self.reset_search()
        if self.dynamic:
            self.snapshot = self.grid.copy()
        algo = REGISTRY[self.algo_key]
        opts = Options(heuristic=self.heuristic, weight=self.epsilon,
                       seed=self.rng.randrange(1 << 30), dynamic=self.dynamic,
                       ants=24, iterations=60)
        self.iterator = algo.search(self.grid, opts)
        self.state = "running"
        self.run_btn.label = "PAUSE"
        if algo.key == "jps" and self.grid.has_weights:
            self.say("JPS is uniform-cost only: terrain weights are ignored for this run", 5)

    def step_once(self):
        if self.iterator is None:
            self.start_search()
            self.state = "paused"
        self.pump(1)

    def steps_per_frame(self) -> int:
        if self.speed >= 100:
            return 3_000_000
        return max(1, int(2 ** (self.speed / 8.0)))

    def pump(self, n: int):
        if self.iterator is None:
            return
        t0 = time.perf_counter()
        try:
            for _ in range(n):
                ev = next(self.iterator)
                self.apply_event(ev)
                if self.state == "done":
                    break
        except StopIteration:
            self.finish()
        self.stats.seconds += time.perf_counter() - t0

    def finish(self):
        self.iterator = None
        self.state = "done" if self.path else "failed"
        self.run_btn.label = "RUN"
        self.repaint_overlay(final=True)
        if not self.path:
            self.say("No path exists between start and goal", 6)

    def apply_event(self, ev):
        k = ev.kind
        if k == "expand":
            idx = self.stats.expanded
            self.stats.expanded += 1
            self.order[ev.node] = idx
            self.gval[ev.node] = ev.value
            self.frontier.discard(ev.node)
            self.paint_cell(ev.node, "expand", idx, ev.value)
        elif k == "frontier":
            self.stats.discovered += 1
            if ev.node not in self.frontier and self.order[ev.node] < 0:
                self.frontier.add(ev.node)
                self.paint_cell(ev.node, "frontier")
            self.stats.frontier_peak = max(self.stats.frontier_peak, len(self.frontier))
        elif k == "scan":
            self.stats.scanned += 1
            if self.order[ev.node] < 0:
                self.paint_cell(ev.node, "scan")
        elif k == "pheromone":
            self.pheromone[ev.node] = ev.value
            self.paint_cell(ev.node, "pheromone", value=ev.value)
        elif k == "path":
            self.path = list(ev.path)
            self.path_progress = 0.0
            self.stats.path_nodes = len(self.path)
            self.stats.path_cost = ev.value or self.grid.path_cost(self.path)
            self.stats.path_length = self.grid.path_length(self.path)
            if ev.text:
                self.last_repair = ev.text
            if self.algo_key != "dstar" or not self.dynamic:
                self.state = "done"
                self.iterator = None
                self.run_btn.label = "RUN"
        elif k == "agent":
            self.agent = ev.node
        elif k == "wall":
            self.grid.set_wall(ev.node, ev.flag)
            self.base_dirty = True
            self.paint_cell(ev.node, "wallflash", flag=ev.flag)
        elif k == "info":
            self.say(ev.text, 5)

    # ================================================================= painting
    def paint_cell(self, node: int, kind: str, idx: int = 0, value: float = 0.0,
                   flag: bool = False):
        r = self.cell_rect(node)
        if kind == "expand":
            if self.heatmap:
                h0 = heuristic_for(self.grid, self.heuristic)
                sx, sy = self.grid.pos(self.grid.start)
                gx, gy = self.grid.pos(self.grid.goal)
                scale = max(1.0, 2.2 * h0(sx, sy, gx, gy))
                t = min(1.0, (value if value != INF else scale) / scale)
                col = self.palette[min(255, int(t * 255))]
            else:
                scale = max(24.0, 0.30 * self.grid.size)
                col = self.palette[min(255, int(255 * idx / scale))]
            pygame.draw.rect(self.overlay, (*col, 148), r)
        elif kind == "frontier":
            pygame.draw.rect(self.overlay, (96, 158, 226, 95), r)
        elif kind == "scan":
            pygame.draw.rect(self.overlay, (150, 175, 210, 34), r)
        elif kind == "pheromone":
            pygame.draw.rect(self.overlay, (188, 140, 255, int(30 + 150 * value)), r)
        elif kind == "wallflash":
            pygame.draw.rect(self.overlay, (248, 81, 73, 110) if flag else (63, 185, 80, 90), r)

    def repaint_overlay(self, final: bool = False):
        self.overlay.fill((0, 0, 0, 0))
        h0 = heuristic_for(self.grid, self.heuristic)
        sx, sy = self.grid.pos(self.grid.start)
        gx, gy = self.grid.pos(self.grid.goal)
        gscale = max(1.0, 2.2 * h0(sx, sy, gx, gy))
        oscale = max(24.0, self.stats.expanded if final else 0.30 * self.grid.size)
        for i, o in enumerate(self.order):
            if o < 0:
                continue
            if self.heatmap:
                v = self.gval[i]
                t = min(1.0, (v if v != INF else gscale) / gscale)
            else:
                t = min(1.0, o / oscale)
            col = self.palette[min(255, int(t * 255))]
            pygame.draw.rect(self.overlay, (*col, 148), self.cell_rect(i))
        for i in self.frontier:
            if self.order[i] < 0:
                pygame.draw.rect(self.overlay, (96, 158, 226, 95), self.cell_rect(i))
        for i, v in self.pheromone.items():
            pygame.draw.rect(self.overlay, (188, 140, 255, int(30 + 150 * v)), self.cell_rect(i))

    def render_base(self):
        g, c = self.grid, self.cell
        self.base.fill(FLOOR)
        maxw = max(g.weight) if g.has_weights else 1.0
        for y in range(g.rows):
            for x in range(g.cols):
                i = y * g.cols + x
                r = pygame.Rect(x * c, y * c, c, c)
                if g.walls[i]:
                    pygame.draw.rect(self.base, WALL, r)
                    if c >= 8:
                        pygame.draw.rect(self.base, WALL_EDGE, r, width=1)
                elif g.weight[i] > 1.001:
                    t = (g.weight[i] - 1.0) / max(1e-6, maxw - 1.0)
                    col = (int(26 + 74 * t), int(32 + 50 * t), int(28 + 14 * t))
                    pygame.draw.rect(self.base, col, r)
                    if c >= 14:
                        pygame.draw.rect(self.base, (58, 58, 44), r, width=1)
                elif c >= 10:
                    pygame.draw.rect(self.base, (24, 30, 40), r, width=1)
        self.base_dirty = False

    # ================================================================== drawing
    def draw(self):
        s = self.screen
        f = self.fonts
        s.fill(BG)
        if self.base_dirty:
            self.render_base()
        s.blit(self.base, self.origin)
        s.blit(self.overlay, self.origin)
        self.draw_path()
        self.draw_markers()
        self.draw_hover()
        self.draw_topbar()
        self.draw_sidebar()
        self.draw_telemetry()
        self.draw_legend()
        self.draw_message()
        if self.compare_results:
            self.draw_benchmark()
        pygame.display.flip()

    def draw_path(self):
        if len(self.path) < 2:
            return
        pts = [self.cell_center(i) for i in self.path]
        k = max(2, min(len(pts), int(self.path_progress) + 2))
        seg = pts[:k]
        w = max(2, self.cell // 4)
        glow = pygame.Surface(self.screen.get_size(), pygame.SRCALPHA)
        pygame.draw.lines(glow, (255, 190, 60, 46), False, seg, w + 8)
        self.screen.blit(glow, (0, 0))
        pygame.draw.lines(self.screen, (150, 108, 24), False, seg, w + 2)
        pygame.draw.lines(self.screen, GOLD, False, seg, w)
        if self.cell >= 12:
            for p in seg:
                pygame.draw.circle(self.screen, (255, 226, 150), p, max(1, w // 3))
        # travelling pulse
        if self.path_progress >= len(pts) - 1:
            t = (pygame.time.get_ticks() / 1000.0 * 8.0) % (len(pts) - 1)
            i = int(t)
            frac = t - i
            a, b = pts[i], pts[min(i + 1, len(pts) - 1)]
            p = (int(a[0] + (b[0] - a[0]) * frac), int(a[1] + (b[1] - a[1]) * frac))
            pygame.draw.circle(self.screen, (255, 255, 235), p, max(3, self.cell // 3))
            pygame.draw.circle(self.screen, GOLD, p, max(5, self.cell // 2), 2)

    def draw_markers(self):
        c = self.cell
        for node, col, letter in ((self.grid.start, GREEN, "S"), (self.grid.goal, RED, "G")):
            p = self.cell_center(node)
            pygame.draw.circle(self.screen, col, p, max(4, int(c * 0.42)))
            pygame.draw.circle(self.screen, BG, p, max(4, int(c * 0.42)), 2)
            if c >= 14:
                text(self.screen, self.fonts.bold, letter, p, BG, "center")
        if self.agent >= 0:
            p = self.cell_center(self.agent)
            pygame.draw.circle(self.screen, (245, 250, 255), p, max(4, int(c * 0.36)))
            pygame.draw.circle(self.screen, CYAN, p, max(6, int(c * 0.55)), 2)

    def draw_hover(self):
        if self.hover_cell >= 0 and not self.compare_results:
            x, y = self.grid.pos(self.hover_cell)
            r = pygame.Rect(self.origin[0] + x * self.cell, self.origin[1] + y * self.cell,
                            self.cell, self.cell)
            pygame.draw.rect(self.screen, (200, 220, 255), r, width=1)

    def draw_topbar(self):
        f = self.fonts
        pygame.draw.rect(self.screen, PANEL, pygame.Rect(0, 0, self.sidebar.x, TOPBAR_H))
        pygame.draw.line(self.screen, BORDER, (0, TOPBAR_H - 1), (self.sidebar.x, TOPBAR_H - 1))
        text(self.screen, f.title, "MAZE", (16, 10), TEXT)
        text(self.screen, f.title, "LAB", (16 + f.title.size("MAZE")[0] + 6, 10), ACCENT)
        text(self.screen, f.tiny, "pathfinding playground", (16, 30), DIM)
        for b in self.widgets:
            if b.rect.x < self.sidebar.x:
                b.draw(self.screen, f)
        status = {"idle": ("READY", DIM), "running": ("SEARCHING", ACCENT),
                  "paused": ("PAUSED", GOLD), "done": ("SOLVED", GREEN),
                  "failed": ("NO PATH", RED)}[self.state]
        cx = 700
        pygame.draw.circle(self.screen, status[1], (cx, 22), 5)
        text(self.screen, f.bold, status[0], (cx + 12, 13), status[1])
        algo = REGISTRY[self.algo_key]
        text(self.screen, f.small, algo.name, (cx + 12, 28), DIM)
        text(self.screen, f.tiny, f"{self.fps:4.0f} fps", (self.sidebar.x - 60, 16), DIM)

    def draw_sidebar(self):
        f = self.fonts
        pygame.draw.rect(self.screen, PANEL, self.sidebar)
        pygame.draw.line(self.screen, BORDER, (self.sidebar.x, 0), (self.sidebar.x, self.H))
        x = self.sidebar.x + 14
        text(self.screen, f.head, "ALGORITHM", (x, 12), DIM)
        for b in self.widgets:
            if b.rect.x >= self.sidebar.x:
                b.draw(self.screen, f)
        algo = REGISTRY[self.algo_key]
        for i, line in enumerate(wrap(algo.blurb, f.tiny, SIDEBAR_W - 28)[:3]):
            text(self.screen, f.tiny, line, (x, self.blurb_y + i * 15), DIM)
        text(self.screen, f.head, "MAZE", (x, self.maze_head_y), DIM)
        text(self.screen, f.head, "SEARCH", (x, self.search_head_y), DIM)
        hints = ["Space run/pause   N step   R reset   G new maze",
                 "B benchmark   D 8-way   H heatmap   S screenshot",
                 "Left-drag paints, right-drag erases. Keys 1-5 pick the tool."]
        for i, h in enumerate(hints):
            text(self.screen, f.tiny, h, (x, self.hint_y + i * 15), (110, 120, 132))

    def draw_telemetry(self):
        f = self.fonts
        r = self.statusbar
        pygame.draw.rect(self.screen, PANEL, r)
        pygame.draw.line(self.screen, BORDER, (r.x, r.y), (r.right, r.y))
        st = self.stats
        solved = bool(self.path)
        items = [("EXPANSIONS", f"{st.expanded:,}", TEXT),
                 ("FRONTIER PEAK", f"{st.frontier_peak:,}", TEXT),
                 ("JUMP SCANS", f"{st.scanned:,}", TEXT),
                 ("PATH CELLS", f"{st.path_nodes:,}", GOLD if solved else DIM),
                 ("PATH COST", f"{st.path_cost:.2f}", GOLD if solved else DIM),
                 ("PATH LENGTH", f"{st.path_length:.2f}", TEXT),
                 ("SOLVE TIME", f"{st.seconds * 1000:.2f} ms", CYAN),
                 ("MOVEMENT", ("8-way" if self.grid.diagonal else "4-way") +
                  (" + mud" if self.grid.has_weights else ""), DIM)]
        cw = r.w // len(items)
        for i, (k, v, col) in enumerate(items):
            x = r.x + 16 + i * cw
            text(self.screen, f.tiny, k, (x, r.y + 12), (112, 122, 134))
            text(self.screen, f.body, v, (x, r.y + 28), col)
        pygame.draw.line(self.screen, (36, 42, 51), (r.x + 12, r.y + 58),
                         (r.right - 12, r.y + 58))

    def draw_legend(self):
        f = self.fonts
        items = [(self.palette[30], "visited"), ((96, 158, 226), "frontier"),
                 ((150, 175, 210), "scanned"), (GOLD, "path"), ((100, 82, 42), "mud"),
                 (PURPLE, "pheromone"), (GREEN, "start"), (RED, "goal")]
        x = self.statusbar.x + 16
        y = self.statusbar.y + 72
        for col, label in items:
            pygame.draw.rect(self.screen, col, pygame.Rect(x, y + 3, 10, 10), border_radius=2)
            text(self.screen, f.tiny, label, (x + 15, y + 2), DIM)
            x += f.tiny.size(label)[0] + 34
        info = f"{mazegen.GEN_LABELS[self.gen_kind]}  -  {self.grid.cols}x{self.grid.rows}"
        text(self.screen, f.tiny, info, (self.statusbar.right - 16, y + 2), (112, 122, 134),
             "topright")

    def draw_message(self):
        if not self.message or time.time() > self.message_until:
            return
        f = self.fonts
        tw = f.small.size(self.message)[0] + 28
        r = pygame.Rect(self.grid_area.centerx - tw // 2, self.grid_area.y + 12, tw, 30)
        s = pygame.Surface((tw, 30), pygame.SRCALPHA)
        s.fill((24, 32, 44, 235))
        pygame.draw.rect(s, ACCENT, s.get_rect(), width=1, border_radius=8)
        text(s, f.small, self.message, (tw // 2, 15), TEXT, "center")
        self.screen.blit(s, r)

    # ================================================================ benchmark
    def benchmark(self):
        self.say("Benchmarking 10 algorithms...", 2)
        self.draw()
        results = []
        base = self.grid.copy()
        ref_cost = None
        for key in ORDER:
            g = base.copy()
            algo = REGISTRY[key]
            opts = Options(heuristic=self.heuristic, weight=self.epsilon, seed=7,
                           dynamic=False, ants=16, iterations=25)
            exp = scans = 0
            path, cost = (), None
            t0 = time.perf_counter()
            for ev in algo.search(g, opts):
                if ev.kind == "expand":
                    exp += 1
                elif ev.kind == "scan":
                    scans += 1
                elif ev.kind == "path":
                    path, cost = ev.path, ev.value
            dt = time.perf_counter() - t0
            if key == "dijkstra":
                ref_cost = cost
            results.append({"key": key, "name": algo.name, "tag": algo.tag,
                            "exp": exp, "scans": scans, "cost": cost,
                            "cells": len(path), "ms": dt * 1000,
                            "optimal": algo.optimal, "weighted_ok": algo.weighted_ok})
        for r in results:
            r["ratio"] = (r["cost"] / ref_cost) if (r["cost"] and ref_cost) else None
        self.compare_results = results
        self.state = "paused" if self.iterator else self.state

    def draw_benchmark(self):
        f = self.fonts
        res = self.compare_results
        w, h = 940, 600
        r = pygame.Rect((self.W - w) // 2, (self.H - h) // 2, w, h)
        shade = pygame.Surface((self.W, self.H), pygame.SRCALPHA)
        shade.fill((6, 9, 14, 210))
        self.screen.blit(shade, (0, 0))
        panel(self.screen, r, (18, 23, 31), ACCENT, radius=14)
        text(self.screen, f.big, "ALGORITHM BENCHMARK", (r.x + 24, r.y + 18), TEXT)
        text(self.screen, f.small,
             f"{self.grid.cols}x{self.grid.rows} grid - "
             f"{'8-way' if self.grid.diagonal else '4-way'} - "
             f"{'weighted terrain' if self.grid.has_weights else 'uniform cost'} - "
             f"{mazegen.GEN_LABELS[self.gen_kind]}",
             (r.x + 24, r.y + 54), DIM)
        cols = [(24, "ALGORITHM", "left"), (330, "EXPANDED", "right"), (430, "SCANS", "right"),
                (540, "PATH COST", "right"), (620, "CELLS", "right"), (720, "TIME ms", "right"),
                (760, "RELATIVE WORK (log)", "left")]
        head_y = r.y + 84
        for dx, label, align in cols:
            if align == "right":
                text(self.screen, f.head, label, (r.x + dx, head_y), DIM, "topright")
            else:
                text(self.screen, f.head, label, (r.x + dx, head_y), DIM)
        pygame.draw.line(self.screen, BORDER, (r.x + 24, head_y + 20), (r.right - 24, head_y + 20))
        max_exp = max(1, max(x["exp"] for x in res))
        best_ms = min(x["ms"] for x in res)
        y = head_y + 30
        for item in sorted(res, key=lambda z: z["exp"]):
            col = GREEN if item["key"] == "jps" else TEXT
            row = pygame.Rect(r.x + 18, y - 4, w - 36, 38)
            if item["ms"] == best_ms:
                pygame.draw.rect(self.screen, (26, 40, 30), row, border_radius=6)
            text(self.screen, f.body, item["name"], (r.x + 24, y), col)
            text(self.screen, f.tiny, item["tag"], (r.x + 24, y + 18), DIM)
            text(self.screen, f.mono, f"{item['exp']:,}", (r.x + 330, y + 4), TEXT, "topright")
            text(self.screen, f.mono, f"{item['scans']:,}", (r.x + 430, y + 4), DIM, "topright")
            uniform_only = (not item["weighted_ok"]) and self.grid.has_weights
            if item["cost"] is None:
                cost_s, cc = "no path", RED
            elif uniform_only:
                cost_s, cc = f"{item['cost']:.2f}*", DIM
            else:
                cost_s, cc = f"{item['cost']:.2f}", TEXT
                if item["ratio"] and item["ratio"] > 1.001:
                    cc = GOLD if item["ratio"] < 1.5 else RED
            text(self.screen, f.mono, cost_s, (r.x + 540, y + 4), cc, "topright")
            text(self.screen, f.mono, str(item["cells"]), (r.x + 620, y + 4), DIM, "topright")
            text(self.screen, f.mono, f"{item['ms']:.1f}", (r.x + 720, y + 4), TEXT, "topright")
            frac = math.log1p(item["exp"]) / math.log1p(max_exp)
            bar = pygame.Rect(r.x + 760, y + 6, max(3, int(140 * frac)), 10)
            pygame.draw.rect(self.screen, (36, 44, 56), pygame.Rect(r.x + 760, y + 6, 140, 10),
                             border_radius=5)
            pygame.draw.rect(self.screen, ACCENT if item["optimal"] else PURPLE, bar,
                             border_radius=5)
            y += 42
        notes = ("Bars = node expansions on a log scale (the real work metric). Gold/red cost = above "
                 "optimal. * = uniform-cost solver, terrain weight ignored. Theta* is any-angle, so "
                 "its cost is continuous-space, not step-for-step. Times include event overhead.")
        for i, line in enumerate(wrap(notes, f.tiny, w - 48)):
            text(self.screen, f.tiny, line, (r.x + 24, r.bottom - 58 + i * 14), DIM)
        text(self.screen, f.small, "press B or Esc or click to close",
             (r.right - 24, r.bottom - 24), ACCENT, "bottomright")

    # =================================================================== input
    def handle_event(self, ev):
        if ev.type == pygame.QUIT:
            self.running = False
            return
        if ev.type == pygame.MOUSEMOTION:
            self.mouse = ev.pos
            for w in self.widgets:
                w.update_hover(ev.pos)
            self.hover_cell = self.cell_at(ev.pos) if self.grid_area.collidepoint(ev.pos) else -1
            if self.painting and self.hover_cell >= 0:
                self.paint_drag(self.hover_cell)
        if self.compare_results:
            if ev.type == pygame.KEYDOWN and ev.key in (pygame.K_ESCAPE, pygame.K_b):
                self.compare_results = None
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                self.compare_results = None
            return
        for w in self.widgets:
            if w.handle(ev, self):
                return
        if ev.type == pygame.MOUSEBUTTONDOWN and self.grid_area.collidepoint(ev.pos):
            i = self.cell_at(ev.pos)
            if i >= 0:
                self.painting = True
                self.paint_button = ev.button
                self.paint_last = i
                self.paint(i, ev.button)
            return
        if ev.type == pygame.MOUSEBUTTONUP:
            self.painting = False
            self.paint_last = None
            return
        if ev.type == pygame.KEYDOWN:
            self.handle_key(ev)

    def handle_key(self, ev):
        k = ev.key
        if k == pygame.K_ESCAPE:
            self.running = False
        elif k == pygame.K_SPACE:
            self.toggle_run()
        elif k == pygame.K_n:
            self.step_once()
        elif k == pygame.K_r:
            self.reset_search()
            self.say("Search reset")
        elif k == pygame.K_g:
            self.new_maze()
        elif k == pygame.K_c:
            self.clear_maze()
        elif k == pygame.K_b:
            self.benchmark()
        elif k == pygame.K_s:
            self.save_screenshot()
        elif k == pygame.K_d:
            self.diag_btn.active = not self.diag_btn.active
            self.toggle_diagonal()
        elif k == pygame.K_t:
            self.weight_btn.active = not self.weight_btn.active
            self.toggle_terrain()
        elif k == pygame.K_h:
            self.heat_btn.active = not self.heat_btn.active
            self.toggle_heatmap()
        elif k == pygame.K_o:
            self.dyn_btn.active = not self.dyn_btn.active
            self.toggle_dynamic()
        elif k == pygame.K_TAB:
            i = ORDER.index(self.algo_key)
            self.select_algorithm(ORDER[(i + (1 if not ev.mod & pygame.KMOD_SHIFT else -1))
                                         % len(ORDER)])
        elif k in (pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5):
            self.set_tool(TOOLS[k - pygame.K_1][0])
        elif k in (pygame.K_PLUS, pygame.K_EQUALS):
            self.speed_slider.set(self.speed + 8, self)
        elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
            self.speed_slider.set(self.speed - 8, self)
        elif k == pygame.K_LEFTBRACKET:
            self.gen_choice.cycle(-1, self)
        elif k == pygame.K_RIGHTBRACKET:
            self.gen_choice.cycle(1, self)

    # ------------------------------------------------------------------ editing
    def paint_drag(self, cell: int):
        if self.paint_last is None or self.paint_last == cell:
            return
        x0, y0 = self.grid.pos(self.paint_last)
        x1, y1 = self.grid.pos(cell)
        steps = max(abs(x1 - x0), abs(y1 - y0))
        for s in range(1, steps + 1):
            x = round(x0 + (x1 - x0) * s / steps)
            y = round(y0 + (y1 - y0) * s / steps)
            self.paint(self.grid.idx(x, y), self.paint_button)
        self.paint_last = cell

    def paint(self, i: int, button: int):
        g = self.grid
        tool = "erase" if button == 3 else self.tool
        if i in (g.start, g.goal) and tool in ("wall", "terrain"):
            return
        if tool == "start":
            g.set_wall(i, False)
            g.start = i
        elif tool == "goal":
            g.set_wall(i, False)
            g.goal = i
        elif tool == "wall":
            g.set_wall(i, True)
        elif tool == "erase":
            g.set_wall(i, False)
            g.set_weight(i, 1.0)
        elif tool == "terrain":
            g.set_wall(i, False)
            g.set_weight(i, 1.0 if g.weight[i] > 3.0 else 7.0)
        self.base_dirty = True
        self.snapshot = None
        if self.state != "idle":
            self.reset_search(restore=False)

    # ------------------------------------------------------------------- output
    def save_screenshot(self, path: str | None = None):
        os.makedirs("screenshots", exist_ok=True)
        path = path or f"screenshots/maze_lab_{datetime.now():%Y%m%d_%H%M%S}.png"
        pygame.image.save(self.screen, path)
        self.say(f"Saved {path}", 4)
        return path

    # --------------------------------------------------------------------- loop
    def update(self, dt: float):
        if self.state == "running":
            self.pump(self.steps_per_frame())
            if self.iterator is None and self.state == "running":
                self.finish()
        if self.path:
            self.path_progress = min(len(self.path) - 1,
                                     self.path_progress + dt * max(20.0, len(self.path) * 1.2))
        self.run_btn.label = "PAUSE" if self.state == "running" else "RUN"
        self.fps = self.clock.get_fps() if not self.headless else 60.0

    def frame(self, dt: float = 1 / 60):
        for ev in pygame.event.get():
            self.handle_event(ev)
        self.update(dt)
        self.draw()

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.frame(dt)
        pygame.quit()
