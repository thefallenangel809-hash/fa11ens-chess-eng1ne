"""D* Lite (Koenig & Likhachev 2002) - incremental replanning.

Instead of restarting the search when the world changes, D* Lite keeps g/rhs
values and a priority queue keyed by (min(g,rhs) + h(s_start) + km) and repairs
only the affected part of the search tree.  It plans backwards from the goal so
the agent can move while the map keeps changing.
"""
from __future__ import annotations

import heapq
import random
from typing import Iterator

from ..grid import INF
from ..heuristics import heuristic_for
from .base import Algorithm, Event, Options


class DStarLiteCore:
    def __init__(self, grid, start: int, goal: int, heuristic: str = "auto"):
        self.grid = grid
        self.n = grid.size
        self.s_start = start
        self.s_goal = goal
        self.s_last = start
        self.km = 0.0
        self.g = [INF] * self.n
        self.rhs = [INF] * self.n
        self.rhs[goal] = 0.0
        self.hf = heuristic_for(grid, heuristic)
        self.gx, self.gy = grid.pos(goal)
        self.U: list[tuple[float, float, int]] = []
        self.key: dict[int, tuple[float, float] | None] = {}
        self.push(goal)
        self.expansions = 0
        self.replans = 0

    # ------------------------------------------------------------- internals
    def h(self, u: int) -> float:
        ux, uy = self.grid.pos(u)
        return self.hf(self.s_start % self.grid.cols, self.s_start // self.grid.cols, ux, uy)

    def calc_key(self, u: int) -> tuple[float, float]:
        m = min(self.g[u], self.rhs[u])
        return (m + self.h(u) + self.km, m)

    def push(self, u: int) -> None:
        k = self.calc_key(u)
        self.key[u] = k
        heapq.heappush(self.U, (k[0], k[1], u))

    def drop(self, u: int) -> None:
        self.key[u] = None

    def top_key(self) -> tuple[float, float]:
        while self.U:
            k1, k2, u = self.U[0]
            if self.key.get(u) != (k1, k2):
                heapq.heappop(self.U)
                continue
            return (k1, k2)
        return (INF, INF)

    def succ(self, u: int):
        if self.grid.walls[u]:
            return ()
        return self.grid.neighbors(u)

    def update_vertex(self, u: int) -> None:
        if u != self.s_goal:
            best = INF
            for v, c in self.succ(u):
                t = c + self.g[v]
                if t < best:
                    best = t
            self.rhs[u] = best
        self.drop(u)
        if self.g[u] != self.rhs[u]:
            self.push(u)

    # ----------------------------------------------------------------- search
    def compute(self, budget: int = 400_000) -> Iterator[Event]:
        self.replans += 1
        guard = 0
        while (self.top_key() < self.calc_key(self.s_start)
               or self.rhs[self.s_start] != self.g[self.s_start]):
            k_old = self.top_key()
            if k_old[0] == INF:
                break
            _, _, u = heapq.heappop(self.U)
            self.drop(u)
            k_new = self.calc_key(u)
            if k_old < k_new:
                self.key[u] = k_new
                heapq.heappush(self.U, (k_new[0], k_new[1], u))
            elif self.g[u] > self.rhs[u]:
                self.g[u] = self.rhs[u]
                self.expansions += 1
                yield Event("expand", u, value=self.g[u])
                for v, _ in self.grid.neighbors(u):
                    self.update_vertex(v)
            else:
                self.g[u] = INF
                self.expansions += 1
                yield Event("expand", u, value=INF)
                for v, _ in self.grid.neighbors(u):
                    self.update_vertex(v)
                self.update_vertex(u)
            guard += 1
            if guard > budget:
                yield Event("info", text="D* Lite expansion budget reached.")
                return

    def notify_changed(self, cells) -> None:
        self.km += self.h(self.s_last)
        self.s_last = self.s_start
        for c in cells:
            self.update_vertex(c)
            for v, _ in self.grid.neighbors(c):
                self.update_vertex(v)

    def extract_path(self, limit: int = 100_000) -> tuple[int, ...]:
        if self.g[self.s_start] == INF:
            return ()
        path = [self.s_start]
        u = self.s_start
        while u != self.s_goal and len(path) < limit:
            best, bv = INF, -1
            for v, c in self.succ(u):
                t = c + self.g[v]
                if t < best - 1e-12:
                    best, bv = t, v
            if bv < 0 or best == INF:
                return ()
            u = bv
            path.append(u)
        return tuple(path)


class DStarLite(Algorithm):
    key = "dstar"
    name = "D* Lite (incremental)"
    tag = "replanning"
    blurb = ("Repairs its previous search instead of restarting. Turn on Dynamic "
             "Obstacles and watch the agent re-route around walls that appear mid-walk.")
    incremental = True

    def search(self, grid, opts: Options) -> Iterator[Event]:
        core = DStarLiteCore(grid, grid.start, grid.goal, opts.heuristic)
        yield Event("info", text="D* Lite: planning backwards from the goal")
        yield from core.compute()
        path = core.extract_path()
        if not path:
            yield Event("info", text="No path exists (start and goal are disconnected).")
            return
        yield Event("path", path=path, value=core.g[grid.start])
        if not opts.dynamic:
            return

        # ------------------------------------------------- dynamic world demo
        rng = random.Random(opts.seed)
        agent = grid.start
        dynamic: list[int] = []
        yield Event("agent", agent)
        yield Event("info", text="Dynamic mode: walls appear/vanish while the agent walks")
        steps = 0
        max_steps = grid.size
        while agent != grid.goal and steps < max_steps:
            # ---- mutate the world somewhere near (but not on top of) the agent
            if rng.random() < opts.obstacle_rate:
                ax, ay = grid.pos(agent)
                radius = 7
                for _ in range(24):
                    x = ax + rng.randint(-radius, radius)
                    y = ay + rng.randint(-radius, radius)
                    if not grid.inside(x, y) or x in (0, grid.cols - 1) or y in (0, grid.rows - 1):
                        continue
                    c = grid.idx(x, y)
                    if c in (agent, grid.goal, grid.start):
                        continue
                    if not grid.walls[c] and (not path or c not in path[:2]):
                        grid.set_wall(c, True)
                        dynamic.append(c)
                        core.notify_changed([c])
                        yield Event("wall", c, flag=True)
                        break
                if dynamic and rng.random() < 0.45:
                    c = dynamic.pop(rng.randrange(len(dynamic)))
                    grid.set_wall(c, False)
                    core.notify_changed([c])
                    yield Event("wall", c, flag=False)

            before = core.expansions
            yield from core.compute()
            repaired = core.expansions - before
            path = core.extract_path()
            if not path:
                yield Event("info", text="Agent trapped: no route left to the goal.")
                return
            yield Event("path", path=path, value=core.g[agent],
                        text=f"replan +{repaired} expansions")
            nxt = path[1] if len(path) > 1 else grid.goal
            agent = nxt
            core.s_start = agent
            yield Event("agent", agent)
            steps += 1
        yield Event("info", text=f"D* Lite reached the goal: {core.replans} replans, "
                                 f"{core.expansions} total expansions")
