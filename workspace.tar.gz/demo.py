"""Headless renderer: produces the README screenshots and an animated GIF.

    SDL_VIDEODRIVER=dummy python main.py --demo
"""
from __future__ import annotations

import os
import random

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame
from PIL import Image

from maze_lab.app import App


def _scene(app, algo, gen, diagonal, weighted, cols, seed):
    app.rng = random.Random(seed)
    app.snapshot = None
    app.grid.resize(cols, max(11, int(cols * 0.66) | 1))
    app.grid.diagonal = diagonal
    app.diag_btn.active = diagonal
    app.weighted = weighted
    app.weight_btn.active = weighted
    app.gen_kind = gen
    app.gen_choice.set(gen)
    app.size_slider.set(app.grid.cols)
    app.new_maze()
    app.select_algorithm(algo)
    app.fps = 60.0


def _snap(app, path):
    pygame.image.save(app.screen, path)
    return path


def render_demo(out_dir: str = "docs"):
    os.makedirs(out_dir, exist_ok=True)
    app = App(headless=True, seed=7)
    frames: list[Image.Image] = []

    def grab(scale=0.72):
        raw = pygame.image.tostring(app.screen, "RGB")
        img = Image.frombytes("RGB", app.screen.get_size(), raw)
        img = img.resize((int(app.W * scale), int(app.H * scale)), Image.LANCZOS)
        frames.append(img.convert("P", palette=Image.ADAPTIVE, colors=128))

    # ---------------------------------------------------- scene 1: A* on mud
    _scene(app, "astar", "braid", diagonal=True, weighted=True, cols=51, seed=12)
    app.speed = 40
    app.start_search()
    app.say("A* on a braided maze with weighted terrain - the wavefront bends around the mud", 999)
    guard = 0
    while app.state == "running" and guard < 400:
        app.update(1 / 30)
        app.draw()
        if guard % 2 == 0:
            grab()
        guard += 1
    for _ in range(14):
        app.update(1 / 30)
        app.draw()
    app.message_until = 0
    app.path_progress = len(app.path)
    app.draw()
    hero = _snap(app, os.path.join(out_dir, "preview.png"))
    for _ in range(6):
        grab()

    # ---------------------------------------------------- scene 2: JPS jumps
    _scene(app, "jps", "braid", diagonal=True, weighted=False, cols=51, seed=5)
    app.speed = 30
    app.start_search()
    app.say("Jump Point Search - only obstacle corners enter the open list", 999)
    guard = 0
    while app.state == "running" and guard < 400:
        app.update(1 / 30)
        app.draw()
        if guard % 3 == 0:
            grab()
        guard += 1
    for _ in range(10):
        app.update(1 / 30)
        app.draw()
    app.message_until = 0
    app.path_progress = len(app.path)
    app.draw()
    _snap(app, os.path.join(out_dir, "jps.png"))
    for _ in range(4):
        grab()

    # ---------------------------------------------------- scene 3: Theta*
    _scene(app, "theta", "rooms", diagonal=True, weighted=False, cols=51, seed=3)
    app.speed = 55
    app.start_search()
    app.say("Theta* - any-angle paths cut straight across open rooms", 999)
    guard = 0
    while app.state == "running" and guard < 400:
        app.update(1 / 30)
        app.draw()
        guard += 1
    for _ in range(12):
        app.update(1 / 30)
        app.draw()
    app.message_until = 0
    app.path_progress = len(app.path)
    app.draw()
    _snap(app, os.path.join(out_dir, "theta.png"))

    # ---------------------------------------------------- scene 4: D* Lite
    _scene(app, "dstar", "scatter", diagonal=True, weighted=False, cols=51, seed=8)
    app.dynamic = True
    app.dyn_btn.active = True
    app.speed = 46
    app.start_search()
    app.say("D* Lite - the agent replans as walls appear (red) and vanish (green)", 999)
    guard = 0
    mid = None
    while app.state == "running" and guard < 900:
        app.update(1 / 30)
        app.draw()
        if guard % 6 == 0:
            grab()
        if mid is None and 0 < len(app.path) < 26 and app.agent != app.grid.start:
            app.message_until = 0
            app.path_progress = len(app.path)
            app.draw()
            mid = _snap(app, os.path.join(out_dir, "dstar.png"))
            app.say("D* Lite - the agent replans as walls appear (red) and vanish (green)", 999)
        guard += 1
    if mid is None:
        app.message_until = 0
        app.path_progress = len(app.path)
        app.draw()
        _snap(app, os.path.join(out_dir, "dstar.png"))

    # ---------------------------------------------------- scene 5: benchmark
    _scene(app, "astar", "braid", diagonal=True, weighted=True, cols=51, seed=12)
    app.speed = 100
    app.start_search()
    while app.state == "running":
        app.update(1 / 30)
    app.benchmark()
    app.draw()
    _snap(app, os.path.join(out_dir, "benchmark.png"))
    for _ in range(8):
        grab()

    gif = os.path.join(out_dir, "demo.gif")
    frames[0].save(gif, save_all=True, append_images=frames[1:], duration=110, loop=0,
                   optimize=True, disposal=2)
    pygame.quit()
    print("wrote:", hero, os.path.join(out_dir, "jps.png"), os.path.join(out_dir, "theta.png"),
          os.path.join(out_dir, "dstar.png"), os.path.join(out_dir, "benchmark.png"), gif)
    print(f"GIF: {len(frames)} frames, {os.path.getsize(gif) / 1e6:.2f} MB")
    return hero


if __name__ == "__main__":
    render_demo()
