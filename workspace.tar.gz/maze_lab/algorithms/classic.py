"""Uninformed searches + Dijkstra (the optimality reference)."""
from __future__ import annotations

import heapq
from collections import deque
from typing import Iterator

from ..grid import INF
from .base import Algorithm, Event, Options, reconstruct


class BreadthFirst(Algorithm):
    key = "bfs"
    name = "Breadth-First Search"
    tag = "uninformed"
    blurb = "FIFO wavefront. Optimal only when every step costs the same."
    optimal = True
    weighted_ok = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        start, goal = grid.start, grid.goal
        came = [-1] * grid.size
        seen = bytearray(grid.size)
        seen[start] = 1
        q = deque([start])
        yield Event("frontier", start)
        while q:
            u = q.popleft()
            yield Event("expand", u)
            if u == goal:
                path = reconstruct(came, u)
                yield Event("path", path=path, value=grid.path_cost(path))
                return
            for v, _ in grid.neighbors(u):
                if not seen[v]:
                    seen[v] = 1
                    came[v] = u
                    q.append(v)
                    yield Event("frontier", v)
        yield Event("info", text="No path exists (start and goal are disconnected).")


class DepthFirst(Algorithm):
    key = "dfs"
    name = "Depth-First Search"
    tag = "uninformed"
    blurb = "LIFO plunge. Finds *a* path fast, almost never the shortest one."
    optimal = False
    weighted_ok = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        start, goal = grid.start, grid.goal
        came = [-1] * grid.size
        seen = bytearray(grid.size)
        stack = [start]
        yield Event("frontier", start)
        while stack:
            u = stack.pop()
            if seen[u]:
                continue
            seen[u] = 1
            yield Event("expand", u)
            if u == goal:
                path = reconstruct(came, u)
                yield Event("path", path=path, value=grid.path_cost(path))
                return
            for v, _ in reversed(grid.neighbors(u)):
                if not seen[v]:
                    if came[v] == -1:
                        came[v] = u
                    stack.append(v)
                    yield Event("frontier", v)
        yield Event("info", text="No path exists (start and goal are disconnected).")


class Dijkstra(Algorithm):
    key = "dijkstra"
    name = "Dijkstra / Uniform Cost"
    tag = "optimal"
    blurb = "Expands by true cost g. Handles terrain weights; the ground truth."

    def search(self, grid, opts: Options) -> Iterator[Event]:
        n = grid.size
        start, goal = grid.start, grid.goal
        dist = [INF] * n
        came = [-1] * n
        closed = bytearray(n)
        dist[start] = 0.0
        heap = [(0.0, start)]
        yield Event("frontier", start)
        while heap:
            d, u = heapq.heappop(heap)
            if closed[u]:
                continue
            closed[u] = 1
            yield Event("expand", u, value=d)
            if u == goal:
                yield Event("path", path=reconstruct(came, u), value=d)
                return
            for v, c in grid.neighbors(u):
                nd = d + c
                if nd < dist[v] - 1e-12:
                    dist[v] = nd
                    came[v] = u
                    heapq.heappush(heap, (nd, v))
                    yield Event("frontier", v)
        yield Event("info", text="No path exists (start and goal are disconnected).")
