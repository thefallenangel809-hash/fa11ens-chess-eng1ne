"""The algorithm line-up."""
from .base import Algorithm, Event, Options, Stats, REGISTRY, register, reconstruct
from .classic import BreadthFirst, DepthFirst, Dijkstra
from .astar import AStar, BidirectionalAStar, ThetaStar
from .jps import JumpPointSearch
from .dstar import DStarLite, DStarLiteCore
from .aco import AntColony

for _a in (
    BreadthFirst(),
    DepthFirst(),
    Dijkstra(),
    AStar(),
    AStar(weighted=True),
    BidirectionalAStar(),
    JumpPointSearch(),
    ThetaStar(),
    DStarLite(),
    AntColony(),
):
    register(_a)

ORDER = ["bfs", "dfs", "dijkstra", "astar", "wastar", "biastar", "jps", "theta", "dstar", "aco"]

__all__ = ["Algorithm", "Event", "Options", "Stats", "REGISTRY", "ORDER",
           "BreadthFirst", "DepthFirst", "Dijkstra", "AStar", "BidirectionalAStar",
           "JumpPointSearch", "ThetaStar", "DStarLite", "DStarLiteCore", "AntColony"]
