"""Admissible / consistent heuristics for grid pathfinding.

Every heuristic is scaled by the cheapest terrain weight in the grid, which
keeps it admissible on weighted maps while staying as informed as possible.
"""
from __future__ import annotations

import math

SQRT2 = math.sqrt(2.0)

HEURISTICS = ("auto", "octile", "manhattan", "euclidean", "chebyshev", "zero")

DESCRIPTIONS = {
    "auto": "Manhattan on 4-way grids, Octile on 8-way grids",
    "octile": "Exact 8-way distance: dx+dy+(sqrt2-2)*min(dx,dy)",
    "manhattan": "|dx|+|dy| - admissible only for 4-way movement",
    "euclidean": "Straight-line distance - needed for any-angle search",
    "chebyshev": "max(dx,dy) - weak but cheap on 8-way grids",
    "zero": "No guidance: A* degenerates into Dijkstra",
}


def make_heuristic(name: str, diagonal: bool, scale: float = 1.0):
    """Return f(ax, ay, bx, by) -> estimated cost."""
    if name == "auto":
        name = "octile" if diagonal else "manhattan"
    if name == "manhattan":
        def h(ax, ay, bx, by):
            return (abs(ax - bx) + abs(ay - by)) * scale
    elif name == "euclidean":
        def h(ax, ay, bx, by):
            return math.hypot(ax - bx, ay - by) * scale
    elif name == "chebyshev":
        def h(ax, ay, bx, by):
            return max(abs(ax - bx), abs(ay - by)) * scale
    elif name == "zero":
        def h(ax, ay, bx, by):
            return 0.0
    else:  # octile
        def h(ax, ay, bx, by):
            dx, dy = abs(ax - bx), abs(ay - by)
            if dx < dy:
                dx, dy = dy, dx
            return (dx + (SQRT2 - 1.0) * dy) * scale
    return h


def heuristic_for(grid, name: str = "auto"):
    return make_heuristic(name, grid.diagonal, grid.min_weight)
