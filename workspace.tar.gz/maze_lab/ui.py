"""Tiny pygame widget toolkit + theme (no external assets, everything drawn)."""
from __future__ import annotations

import pygame

# --------------------------------------------------------------------- theme
BG = (13, 17, 23)
PANEL = (22, 27, 34)
PANEL_HI = (30, 37, 46)
BORDER = (48, 54, 61)
TEXT = (205, 214, 224)
DIM = (136, 146, 158)
ACCENT = (88, 166, 255)
GREEN = (63, 185, 80)
GOLD = (255, 200, 70)
RED = (248, 81, 73)
PURPLE = (188, 140, 255)
CYAN = (57, 211, 213)
WALL = (38, 45, 56)
WALL_EDGE = (56, 66, 80)
FLOOR = (17, 22, 30)


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def make_palette(n: int = 256) -> list[tuple[int, int, int]]:
    """Deep blue -> cyan -> violet gradient for the visited wavefront."""
    stops = [(18, 34, 70), (24, 78, 136), (30, 140, 172), (86, 186, 158), (176, 208, 132)]
    out = []
    for i in range(n):
        t = i / (n - 1) * (len(stops) - 1)
        k = min(int(t), len(stops) - 2)
        out.append(lerp(stops[k], stops[k + 1], t - k))
    return out


class Fonts:
    def __init__(self):
        pygame.font.init()
        def load(size, bold=False, mono=False):
            names = "dejavusansmono,consolas,menlo,monospace" if mono else \
                    "dejavusans,segoeui,arial,helvetica"
            path = pygame.font.match_font(names, bold=bold)
            if path:
                return pygame.font.Font(path, size)
            return pygame.font.Font(None, int(size * 1.15))
        self.tiny = load(12)
        self.small = load(14)
        self.body = load(16)
        self.bold = load(16, bold=True)
        self.head = load(13, bold=True)
        self.title = load(21, bold=True)
        self.big = load(28, bold=True)
        self.mono = load(14, mono=True)
        self.mono_small = load(12, mono=True)


def text(surf, font, s, pos, color=TEXT, anchor="topleft"):
    img = font.render(s, True, color)
    rect = img.get_rect(**{anchor: pos})
    surf.blit(img, rect)
    return rect


def wrap(s: str, font, width: int) -> list[str]:
    lines, cur = [], ""
    for word in s.split():
        trial = (cur + " " + word).strip()
        if font.size(trial)[0] <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def panel(surf, rect, fill=PANEL, border=BORDER, radius=10, width=1):
    pygame.draw.rect(surf, fill, rect, border_radius=radius)
    if border:
        pygame.draw.rect(surf, border, rect, width=width, border_radius=radius)


# ------------------------------------------------------------------- widgets
class Widget:
    def __init__(self, rect, tooltip=""):
        self.rect = pygame.Rect(rect)
        self.tooltip = tooltip
        self.hover = False
        self.enabled = True

    def draw(self, surf, f: Fonts):
        raise NotImplementedError

    def handle(self, ev, app) -> bool:
        return False

    def update_hover(self, mouse):
        self.hover = self.rect.collidepoint(mouse) and self.enabled


class Button(Widget):
    def __init__(self, rect, label, on_click, style="normal", key_hint="", toggle=False):
        super().__init__(rect)
        self.label = label
        self.on_click = on_click
        self.style = style          # normal | primary | ghost
        self.key_hint = key_hint
        self.toggle = toggle
        self.active = False

    def draw(self, surf, f):
        if self.style == "primary":
            fill = (32, 96, 160) if not self.hover else (44, 118, 190)
            border, fg = ACCENT, (235, 245, 255)
        elif self.active:
            fill = (26, 62, 92)
            border, fg = ACCENT, (215, 235, 255)
        elif self.style == "ghost":
            fill = PANEL if not self.hover else PANEL_HI
            border, fg = BORDER, DIM if not self.hover else TEXT
        else:
            fill = PANEL_HI if not self.hover else (40, 49, 61)
            border, fg = BORDER, TEXT
        if not self.enabled:
            fill, fg, border = (20, 24, 30), (86, 94, 104), (36, 41, 48)
        panel(surf, self.rect, fill, border, radius=7)
        if self.toggle:
            dot = pygame.Rect(self.rect.x + 10, self.rect.centery - 4, 8, 8)
            pygame.draw.ellipse(surf, GREEN if self.active else (70, 78, 88), dot)
            tx = self.rect.x + 26
        else:
            tx = self.rect.centerx
        anchor = "midleft" if self.toggle else "center"
        pos = (tx, self.rect.centery) if self.toggle else self.rect.center
        if self.key_hint and not self.toggle:
            lab = f.small.render(self.label, True, fg)
            hint = f.tiny.render(self.key_hint, True, DIM)
            total = lab.get_width() + 8 + hint.get_width()
            sx = self.rect.centerx - total // 2
            surf.blit(lab, lab.get_rect(midleft=(sx, self.rect.centery)))
            surf.blit(hint, hint.get_rect(midleft=(sx + lab.get_width() + 8, self.rect.centery + 1)))
        else:
            text(surf, f.small, self.label, pos, fg, anchor)

    def handle(self, ev, app):
        if not self.enabled:
            return False
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1 and self.rect.collidepoint(ev.pos):
            if self.toggle:
                self.active = not self.active
            self.on_click(app)
            return True
        return False


class Slider(Widget):
    def __init__(self, rect, label, lo, hi, value, on_change, fmt="{:.0f}", step=1):
        super().__init__(rect)
        self.label, self.lo, self.hi, self.value = label, lo, hi, value
        self.on_change, self.fmt, self.step = on_change, fmt, step
        self.dragging = False

    def _track(self):
        return pygame.Rect(self.rect.x + 2, self.rect.y + 24, self.rect.w - 4, 6)

    def set(self, v, app=None, notify=True):
        v = max(self.lo, min(self.hi, v))
        if self.step:
            v = round((v - self.lo) / self.step) * self.step + self.lo
        if v != self.value:
            self.value = v
            if notify and app is not None:
                self.on_change(app, v)

    def draw(self, surf, f):
        text(surf, f.small, self.label, (self.rect.x, self.rect.y + 2), DIM)
        text(surf, f.small, self.fmt.format(self.value), (self.rect.right, self.rect.y + 2),
             ACCENT if self.hover or self.dragging else TEXT, "topright")
        tr = self._track()
        panel(surf, tr, (32, 38, 46), None, radius=3)
        t = (self.value - self.lo) / max(1e-9, self.hi - self.lo)
        fill = pygame.Rect(tr.x, tr.y, int(tr.w * t), tr.h)
        panel(surf, fill, (46, 110, 170), None, radius=3)
        kx = tr.x + int(tr.w * t)
        pygame.draw.circle(surf, ACCENT if (self.hover or self.dragging) else (120, 150, 180),
                           (kx, tr.centery), 7)
        pygame.draw.circle(surf, BG, (kx, tr.centery), 3)

    def _from_x(self, x):
        tr = self._track()
        t = (x - tr.x) / max(1, tr.w)
        return self.lo + max(0.0, min(1.0, t)) * (self.hi - self.lo)

    def handle(self, ev, app):
        if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1 and self.rect.collidepoint(ev.pos):
            self.dragging = True
            self.set(self._from_x(ev.pos[0]), app)
            return True
        if ev.type == pygame.MOUSEBUTTONUP and ev.button == 1:
            self.dragging = False
        if ev.type == pygame.MOUSEMOTION and self.dragging:
            self.set(self._from_x(ev.pos[0]), app)
            return True
        return False


class Choice(Widget):
    def __init__(self, rect, label, options, labels, index, on_change):
        super().__init__(rect)
        self.label, self.options, self.labels = label, options, labels
        self.index, self.on_change = index, on_change

    @property
    def value(self):
        return self.options[self.index]

    def set(self, value, app=None, notify=True):
        if value in self.options:
            i = self.options.index(value)
            if i != self.index:
                self.index = i
                if notify and app is not None:
                    self.on_change(app, self.options[i])

    def cycle(self, d, app):
        self.index = (self.index + d) % len(self.options)
        self.on_change(app, self.options[self.index])

    def draw(self, surf, f):
        panel(surf, self.rect, PANEL_HI if self.hover else PANEL, BORDER, radius=7)
        text(surf, f.tiny, self.label.upper(), (self.rect.x + 10, self.rect.y + 3), DIM)
        text(surf, f.small, self.labels[self.index], (self.rect.x + 10, self.rect.y + 15), TEXT)
        cy = self.rect.centery + 4
        text(surf, f.body, "<", (self.rect.right - 34, cy), DIM, "center")
        text(surf, f.body, ">", (self.rect.right - 14, cy), DIM, "center")

    def handle(self, ev, app):
        if ev.type == pygame.MOUSEBUTTONDOWN and self.rect.collidepoint(ev.pos):
            if ev.button == 3:
                self.cycle(-1, app)
            elif ev.button == 1:
                self.cycle(-1 if ev.pos[0] > self.rect.right - 44 and
                           ev.pos[0] < self.rect.right - 24 else 1, app)
            elif ev.button == 4:
                self.cycle(1, app)
            elif ev.button == 5:
                self.cycle(-1, app)
            return True
        return False
