"""Procedural maze / terrain generators.

All generators work on the shared Grid object and leave it in a solvable state.
Maze carvers operate on odd coordinates so corridors are always 1 cell wide.
"""
from __future__ import annotations

import math
import random
from collections import deque

from .grid import Grid

GENERATORS = (
    "backtracker",
    "prim",
    "kruskal",
    "division",
    "braid",
    "cave",
    "rooms",
    "terrain",
    "scatter",
    "empty",
)

GEN_LABELS = {
    "backtracker": "Recursive backtracker",
    "prim": "Randomised Prim",
    "kruskal": "Randomised Kruskal",
    "division": "Recursive division",
    "braid": "Braided maze (loops)",
    "cave": "Cellular-automata cave",
    "rooms": "BSP rooms + corridors",
    "terrain": "Weighted noise terrain",
    "scatter": "Random obstacle field",
    "empty": "Empty arena",
}


# --------------------------------------------------------------------- utils
def _carve(grid: Grid, x: int, y: int) -> None:
    grid.walls[grid.idx(x, y)] = 0


def _wall(grid: Grid, x: int, y: int) -> None:
    grid.walls[grid.idx(x, y)] = 1


def _fill(grid: Grid) -> None:
    grid.walls = bytearray(b"\x01" * grid.size)
    grid.weight = [1.0] * grid.size


# ------------------------------------------------------------------ carvers
def backtracker(grid: Grid, rng: random.Random) -> None:
    _fill(grid)
    sx, sy = 1, 1
    _carve(grid, sx, sy)
    stack = [(sx, sy)]
    cols, rows = grid.cols, grid.rows
    while stack:
        x, y = stack[-1]
        options = []
        for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
            nx, ny = x + dx, y + dy
            if 0 < nx < cols - 1 and 0 < ny < rows - 1 and grid.walls[grid.idx(nx, ny)]:
                options.append((nx, ny, dx, dy))
        if not options:
            stack.pop()
            continue
        nx, ny, dx, dy = rng.choice(options)
        _carve(grid, x + dx // 2, y + dy // 2)
        _carve(grid, nx, ny)
        stack.append((nx, ny))


def prim(grid: Grid, rng: random.Random) -> None:
    _fill(grid)
    cols, rows = grid.cols, grid.rows
    frontier: list[tuple[int, int, int, int]] = []

    def push(x: int, y: int) -> None:
        for dx, dy in ((2, 0), (-2, 0), (0, 2), (0, -2)):
            nx, ny = x + dx, y + dy
            if 0 < nx < cols - 1 and 0 < ny < rows - 1 and grid.walls[grid.idx(nx, ny)]:
                frontier.append((nx, ny, x, y))

    _carve(grid, 1, 1)
    push(1, 1)
    while frontier:
        k = rng.randrange(len(frontier))
        nx, ny, px, py = frontier[k]
        frontier[k] = frontier[-1]
        frontier.pop()
        if grid.walls[grid.idx(nx, ny)]:
            _carve(grid, (nx + px) // 2, (ny + py) // 2)
            _carve(grid, nx, ny)
            push(nx, ny)


def kruskal(grid: Grid, rng: random.Random) -> None:
    _fill(grid)
    cols, rows = grid.cols, grid.rows
    parent = list(range(grid.size))

    def find(a: int) -> int:
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    edges = []
    for y in range(1, rows - 1, 2):
        for x in range(1, cols - 1, 2):
            _carve(grid, x, y)
            if x + 2 < cols - 1:
                edges.append((grid.idx(x, y), grid.idx(x + 2, y), x + 1, y))
            if y + 2 < rows - 1:
                edges.append((grid.idx(x, y), grid.idx(x, y + 2), x, y + 1))
    rng.shuffle(edges)
    for a, b, wx, wy in edges:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb
            _carve(grid, wx, wy)


def division(grid: Grid, rng: random.Random) -> None:
    grid.clear(keep_border=True)

    def divide(x0: int, y0: int, x1: int, y1: int) -> None:
        w, h = x1 - x0, y1 - y0
        if w < 3 or h < 3:
            return
        horizontal = h > w if h != w else rng.random() < 0.5
        if horizontal:
            wy = rng.randrange(y0 + 1, y1, 2)
            gap = rng.randrange(x0, x1 + 1, 2)
            for x in range(x0, x1 + 1):
                if x != gap:
                    _wall(grid, x, wy)
            divide(x0, y0, x1, wy - 1)
            divide(x0, wy + 1, x1, y1)
        else:
            wx = rng.randrange(x0 + 1, x1, 2)
            gap = rng.randrange(y0, y1 + 1, 2)
            for y in range(y0, y1 + 1):
                if y != gap:
                    _wall(grid, wx, y)
            divide(x0, y0, wx - 1, y1)
            divide(wx + 1, y0, x1, y1)

    divide(1, 1, grid.cols - 2, grid.rows - 2)


def braid(grid: Grid, rng: random.Random, amount: float = 0.85) -> None:
    """Perfect maze with most dead ends removed -> lots of alternative routes."""
    backtracker(grid, rng)
    cols = grid.cols
    dead = []
    for y in range(1, grid.rows - 1):
        for x in range(1, cols - 1):
            i = grid.idx(x, y)
            if grid.walls[i]:
                continue
            open_n = sum(1 for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                         if grid.free(x + dx, y + dy))
            if open_n == 1:
                dead.append((x, y))
    rng.shuffle(dead)
    for x, y in dead:
        if rng.random() > amount:
            continue
        walls = [(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))
                 if 0 < x + dx < cols - 1 and 0 < y + dy < grid.rows - 1
                 and grid.blocked(x + dx, y + dy)]
        if walls:
            nx, ny = rng.choice(walls)
            _carve(grid, nx, ny)


def cave(grid: Grid, rng: random.Random, fill_prob: float = 0.45,
         steps: int = 5) -> None:
    cols, rows = grid.cols, grid.rows
    walls = bytearray(grid.size)
    for y in range(rows):
        for x in range(cols):
            i = y * cols + x
            walls[i] = 1 if (x in (0, cols - 1) or y in (0, rows - 1)
                             or rng.random() < fill_prob) else 0
    for _ in range(steps):
        nxt = bytearray(walls)
        for y in range(1, rows - 1):
            for x in range(1, cols - 1):
                count = 0
                for dy in (-1, 0, 1):
                    for dx in (-1, 0, 1):
                        if dx or dy:
                            count += walls[(y + dy) * cols + x + dx]
                nxt[y * cols + x] = 1 if count >= 5 else 0
        walls = nxt
    grid.walls = walls
    grid.weight = [1.0] * grid.size
    _keep_largest_component(grid)


def _keep_largest_component(grid: Grid) -> None:
    seen = bytearray(grid.size)
    best: list[int] = []
    for i in range(grid.size):
        if grid.walls[i] or seen[i]:
            continue
        comp = []
        dq = deque([i])
        seen[i] = 1
        while dq:
            u = dq.popleft()
            comp.append(u)
            x, y = grid.pos(u)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if grid.free(nx, ny):
                    v = grid.idx(nx, ny)
                    if not seen[v]:
                        seen[v] = 1
                        dq.append(v)
        if len(comp) > len(best):
            best = comp
    keep = set(best)
    for i in range(grid.size):
        if not grid.walls[i] and i not in keep:
            grid.walls[i] = 1


def rooms(grid: Grid, rng: random.Random, max_rooms: int = 14) -> None:
    _fill(grid)
    cols, rows = grid.cols, grid.rows
    boxes: list[tuple[int, int, int, int]] = []

    def split(x0, y0, x1, y1, depth):
        w, h = x1 - x0, y1 - y0
        if depth >= 5 or (w < 11 and h < 11) or (w < 8 or h < 8):
            boxes.append((x0, y0, x1, y1))
            return
        if w > h:
            cut = rng.randint(x0 + 4, x1 - 4)
            split(x0, y0, cut - 1, y1, depth + 1)
            split(cut + 1, y0, x1, y1, depth + 1)
        else:
            cut = rng.randint(y0 + 4, y1 - 4)
            split(x0, y0, x1, cut - 1, depth + 1)
            split(x0, cut + 1, x1, y1, depth + 1)

    split(1, 1, cols - 2, rows - 2, 0)
    centers = []
    for (x0, y0, x1, y1) in boxes:
        rw = rng.randint(3, max(3, x1 - x0))
        rh = rng.randint(3, max(3, y1 - y0))
        rx = rng.randint(x0, max(x0, x1 - rw))
        ry = rng.randint(y0, max(y0, y1 - rh))
        for y in range(ry, min(ry + rh, rows - 1)):
            for x in range(rx, min(rx + rw, cols - 1)):
                _carve(grid, x, y)
        centers.append((rx + rw // 2, ry + rh // 2))
    for (ax, ay), (bx, by) in zip(centers, centers[1:]):
        x, y = ax, ay
        while x != bx:
            _carve(grid, x, y)
            x += 1 if bx > x else -1
        while y != by:
            _carve(grid, x, y)
            y += 1 if by > y else -1
        _carve(grid, x, y)


# ------------------------------------------------------------------ terrain
def _value_noise(cols: int, rows: int, rng: random.Random, octave: int = 4):
    """Cheap smoothed value noise, no numpy required."""
    out = [0.0] * (cols * rows)
    amp, total = 1.0, 0.0
    for o in range(octave):
        res = max(2, (2 ** (o + 1)))
        gw, gh = res + 1, res + 1
        lattice = [rng.random() for _ in range(gw * gh)]
        for y in range(rows):
            fy = y / max(1, rows - 1) * (gh - 1)
            y0 = min(int(fy), gh - 2)
            ty = fy - y0
            ty = ty * ty * (3 - 2 * ty)
            for x in range(cols):
                fx = x / max(1, cols - 1) * (gw - 1)
                x0 = min(int(fx), gw - 2)
                tx = fx - x0
                tx = tx * tx * (3 - 2 * tx)
                a = lattice[y0 * gw + x0]
                b = lattice[y0 * gw + x0 + 1]
                c = lattice[(y0 + 1) * gw + x0]
                d = lattice[(y0 + 1) * gw + x0 + 1]
                top = a + (b - a) * tx
                bot = c + (d - c) * tx
                out[y * cols + x] += (top + (bot - top) * ty) * amp
        total += amp
        amp *= 0.5
    return [v / total for v in out]


def apply_terrain(grid: Grid, rng: random.Random, max_weight: float = 9.0) -> None:
    """Paint traversal costs onto open cells (swamp / mud / road)."""
    noise = _value_noise(grid.cols, grid.rows, rng)
    for i in range(grid.size):
        if grid.walls[i]:
            grid.weight[i] = 1.0
        else:
            grid.weight[i] = 1.0 + (max_weight - 1.0) * (noise[i] ** 1.6)
    grid.invalidate()


def terrain(grid: Grid, rng: random.Random) -> None:
    grid.clear(keep_border=True)
    noise = _value_noise(grid.cols, grid.rows, rng, octave=3)
    for i, v in enumerate(noise):
        if v > 0.62 and rng.random() < 0.85:
            grid.walls[i] = 1
    for x in range(grid.cols):
        grid.walls[grid.idx(x, 0)] = 1
        grid.walls[grid.idx(x, grid.rows - 1)] = 1
    for y in range(grid.rows):
        grid.walls[grid.idx(0, y)] = 1
        grid.walls[grid.idx(grid.cols - 1, y)] = 1
    apply_terrain(grid, rng)


def scatter(grid: Grid, rng: random.Random, density: float = 0.28) -> None:
    grid.clear(keep_border=True)
    for i in range(grid.size):
        if rng.random() < density:
            grid.walls[i] = 1


# ----------------------------------------------------------------- dispatch
def generate(grid: Grid, kind: str, rng: random.Random | None = None,
             weighted: bool = False) -> None:
    rng = rng or random.Random()
    fn = {
        "backtracker": backtracker, "prim": prim, "kruskal": kruskal,
        "division": division, "braid": braid, "cave": cave, "rooms": rooms,
        "terrain": terrain, "scatter": scatter,
        "empty": lambda g, r: g.clear(keep_border=True),
    }.get(kind, backtracker)
    fn(grid, rng)
    grid.start = grid.idx(1, 1)
    grid.goal = grid.idx(grid.cols - 2, grid.rows - 2)
    grid.invalidate()
    grid.ensure_solvable()
    if weighted and kind != "terrain":
        apply_terrain(grid, rng)
    # never let the endpoints sit in deep mud
    grid.weight[grid.start] = 1.0
    grid.weight[grid.goal] = 1.0
    grid.invalidate()
