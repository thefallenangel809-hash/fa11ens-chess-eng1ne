"""Maze Lab - an advanced pygame pathfinding visualiser."""
__version__ = "1.0.0"
