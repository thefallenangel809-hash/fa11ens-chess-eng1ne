"""Correctness tests: every 'optimal' solver must match Dijkstra's cost.

Run:  python -m unittest discover -s tests -v      (or: python main.py --selftest)
"""
from __future__ import annotations

import random
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from maze_lab.grid import Grid
from maze_lab import mazegen
from maze_lab.algorithms import REGISTRY, Options


def run(key, grid, **kw):
    opts = Options(**kw)
    path, cost, expanded = (), None, 0
    for ev in REGISTRY[key].search(grid, opts):
        if ev.kind == "expand":
            expanded += 1
        elif ev.kind == "path":
            path, cost = ev.path, ev.value
    return path, cost, expanded


def reference(grid):
    return run("dijkstra", grid)


class TestOptimality(unittest.TestCase):
    def _grids(self, count=12):
        rng = random.Random(20261121)
        kinds = ["backtracker", "prim", "kruskal", "division", "braid", "cave",
                 "rooms", "scatter", "empty", "terrain"]
        for k in range(count):
            for diagonal in (False, True):
                g = Grid(rng.choice([21, 31, 41]), rng.choice([15, 21, 31]),
                         diagonal=diagonal)
                mazegen.generate(g, kinds[k % len(kinds)], rng,
                                 weighted=(k % 3 == 0))
                yield g

    def test_optimal_solvers_match_dijkstra(self):
        for g in self._grids():
            _, ref_cost, _ = reference(g)
            for key in ("bfs", "astar", "biastar", "dijkstra"):
                if key == "bfs" and (g.diagonal or g.has_weights):
                    continue          # BFS is only optimal on uniform 4-way grids
                path, cost, _ = run(key, g)
                self.assertTrue(path, f"{key} found no path on a solvable grid")
                self.assertEqual(path[0], g.start)
                self.assertEqual(path[-1], g.goal)
                self.assertAlmostEqual(cost, ref_cost, places=6,
                                       msg=f"{key} diag={g.diagonal} weighted={g.has_weights}")
                self.assertAlmostEqual(g.path_cost(path), ref_cost, places=6,
                                       msg=f"{key} reported cost != real path cost")

    def test_jps_matches_astar_uniform(self):
        for g in self._grids(count=14):
            for i in range(g.size):
                g.weight[i] = 1.0
            g.invalidate()
            _, ref_cost, ref_exp = reference(g)
            path, cost, exp = run("jps", g)
            self.assertTrue(path, "JPS found no path")
            self.assertAlmostEqual(cost, ref_cost, places=6,
                                   msg=f"JPS diag={g.diagonal} cost {cost} vs {ref_cost}")
            self.assertAlmostEqual(g.path_cost(path), ref_cost, places=6,
                                   msg="JPS interpolated path is not walkable/consistent")
            self.assertLessEqual(exp, ref_exp,
                                 "JPS should never expand more nodes than Dijkstra")

    def test_weighted_astar_bound(self):
        rng = random.Random(7)
        for _ in range(8):
            g = Grid(31, 21, diagonal=True)
            mazegen.generate(g, "terrain", rng, weighted=True)
            _, ref_cost, _ = reference(g)
            eps = 2.0
            path, cost, _ = run("wastar", g, weight=eps)
            self.assertTrue(path)
            self.assertLessEqual(cost, eps * ref_cost + 1e-6)
            self.assertGreaterEqual(cost, ref_cost - 1e-6)

    def test_theta_star_is_walkable_and_shorter(self):
        rng = random.Random(11)
        for kind in ("empty", "scatter", "rooms", "braid"):
            g = Grid(41, 31, diagonal=True)
            mazegen.generate(g, kind, rng)
            path, cost, _ = run("theta", g)
            self.assertTrue(path)
            for a, b in zip(path, path[1:]):
                self.assertTrue(g.line_of_sight(a, b), "Theta* segment crosses a wall")
            self.assertLessEqual(g.path_length(path), g.path_length(reference(g)[0]) + 1e-6)

    def test_dfs_and_aco_reach_goal(self):
        rng = random.Random(3)
        g = Grid(31, 21)
        mazegen.generate(g, "braid", rng)
        for key in ("dfs", "aco"):
            path, cost, _ = run(key, g, iterations=25, ants=16)
            self.assertTrue(path, f"{key} failed to reach the goal")
            self.assertEqual(path[-1], g.goal)
            for a, b in zip(path, path[1:]):
                self.assertIn(b, [v for v, _ in g.neighbors(a)], f"{key} made an illegal move")

    def test_unsolvable(self):
        g = Grid(21, 15)
        mazegen.generate(g, "empty")
        for y in range(g.rows):
            g.set_wall(g.idx(10, y), True)
        for key in ("bfs", "dfs", "dijkstra", "astar", "biastar", "jps", "theta", "dstar"):
            path, _, _ = run(key, g)
            self.assertFalse(path, f"{key} hallucinated a path through a solid wall")


class TestDynamicReplanning(unittest.TestCase):
    def test_dstar_lite_matches_static_optimum(self):
        rng = random.Random(5)
        for kind in ("braid", "rooms", "scatter"):
            g = Grid(31, 21, diagonal=True)
            mazegen.generate(g, kind, rng)
            _, ref_cost, _ = reference(g)
            path, cost, _ = run("dstar", g)
            self.assertTrue(path)
            self.assertAlmostEqual(cost, ref_cost, places=6)

    def test_dstar_lite_dynamic_walk(self):
        rng = random.Random(9)
        g = Grid(31, 21, diagonal=True)
        mazegen.generate(g, "scatter", rng)
        opts = Options(dynamic=True, obstacle_rate=0.5, seed=42)
        agent, last_path, walls_changed = g.start, (), 0
        for ev in REGISTRY["dstar"].search(g, opts):
            if ev.kind == "agent":
                agent = ev.node
            elif ev.kind == "path":
                last_path = ev.path
            elif ev.kind == "wall":
                walls_changed += 1
        self.assertGreater(walls_changed, 0, "dynamic mode never changed the map")
        self.assertEqual(agent, g.goal, "D* Lite agent did not reach the goal")
        self.assertFalse(g.walls[g.goal])
        self.assertTrue(last_path)


class TestGrid(unittest.TestCase):
    def test_line_of_sight_blocks_walls(self):
        g = Grid(21, 15)
        g.clear(keep_border=True)
        g.set_wall(g.idx(5, 5), True)
        self.assertFalse(g.line_of_sight(g.idx(3, 5), g.idx(7, 5)))
        self.assertTrue(g.line_of_sight(g.idx(3, 3), g.idx(7, 3)))
        self.assertFalse(g.line_of_sight(g.idx(4, 4), g.idx(6, 6)))  # corner cut blocked

    def test_no_corner_cutting(self):
        g = Grid(21, 15, diagonal=True, corner_cutting=False)
        g.clear(keep_border=True)
        g.set_wall(g.idx(5, 4), True)
        nbrs = [v for v, _ in g.neighbors(g.idx(4, 5))]
        self.assertNotIn(g.idx(5, 4), nbrs)
        self.assertNotIn(g.idx(5, 6), nbrs) if g.blocked(5, 6) else None
        # diagonal (4,5)->(5,4) is blocked by the wall itself
        self.assertNotIn(g.idx(5, 4), nbrs)

    def test_generators_all_solvable(self):
        rng = random.Random(1)
        for kind in mazegen.GENERATORS:
            g = Grid(31, 21)
            mazegen.generate(g, kind, rng, weighted=True)
            self.assertIn(g.goal, g.reachable(), f"{kind} produced an unsolvable map")


if __name__ == "__main__":
    unittest.main(verbosity=2)
