"""A* family: classic, epsilon-weighted, bidirectional and any-angle Theta*."""
from __future__ import annotations

import heapq
import math
from typing import Iterator

from ..grid import INF, SQRT2
from ..heuristics import heuristic_for, make_heuristic
from .base import Algorithm, Event, Options, reconstruct


class AStar(Algorithm):
    key = "astar"
    name = "A* (consistent h)"
    tag = "optimal"
    blurb = "f = g + h with tie-break on low h. Optimal for admissible, consistent h."

    def __init__(self, weighted: bool = False):
        self.use_weight = weighted
        if weighted:
            self.key = "wastar"
            self.name = "Weighted A* (epsilon)"
            self.tag = "bounded"
            self.blurb = "f = g + eps*h. At most eps times optimal, usually far fewer expansions."
            self.optimal = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        n = grid.size
        start, goal = grid.start, grid.goal
        h = heuristic_for(grid, opts.heuristic)
        gx, gy = grid.pos(goal)
        sx, sy = grid.pos(start)
        eps = max(1.0, opts.weight) if self.use_weight else 1.0
        g = [INF] * n
        came = [-1] * n
        closed = bytearray(n)
        g[start] = 0.0
        h0 = h(sx, sy, gx, gy)
        counter = 0
        heap = [(eps * h0, h0, counter, start)]
        yield Event("frontier", start)
        if self.use_weight:
            yield Event("info", text=f"Weighted A*: epsilon = {eps:.2f} (cost <= {eps:.2f} x optimal)")
        while heap:
            f, hu, _, u = heapq.heappop(heap)
            if closed[u]:
                continue
            closed[u] = 1
            yield Event("expand", u, value=g[u])
            if u == goal:
                yield Event("path", path=reconstruct(came, u), value=g[u])
                return
            ux, uy = grid.pos(u)
            gu = g[u]
            for v, c in grid.neighbors(u):
                if closed[v]:
                    continue
                ng = gu + c
                if ng < g[v] - 1e-12:
                    g[v] = ng
                    came[v] = u
                    vx, vy = grid.pos(v)
                    hv = h(vx, vy, gx, gy)
                    counter += 1
                    heapq.heappush(heap, (ng + eps * hv, hv, counter, v))
                    yield Event("frontier", v)
        yield Event("info", text="No path exists (start and goal are disconnected).")


class BidirectionalAStar(Algorithm):
    key = "biastar"
    name = "Bidirectional A*"
    tag = "optimal"
    blurb = ("Two front-to-end A* waves meeting in the middle. Stops as soon as "
             "mu <= min(top_f, top_b), which is provably optimal for consistent h.")

    def search(self, grid, opts: Options) -> Iterator[Event]:
        n = grid.size
        start, goal = grid.start, grid.goal
        hf = heuristic_for(grid, opts.heuristic)
        sx, sy = grid.pos(start)
        gx, gy = grid.pos(goal)
        gf, gb = [INF] * n, [INF] * n
        cf, cb = [-1] * n, [-1] * n
        closed_f, closed_b = bytearray(n), bytearray(n)
        gf[start] = gb[goal] = 0.0
        cnt = 0
        open_f = [(hf(sx, sy, gx, gy), 0, cnt, start)]
        open_b = [(hf(gx, gy, sx, sy), 0, cnt, goal)]
        mu = INF
        meet = -1
        yield Event("frontier", start)
        yield Event("frontier", goal)
        yield Event("info", text="Bidirectional A*: forward + backward waves, front-to-end heuristics")

        while open_f and open_b:
            while open_f and closed_f[open_f[0][3]]:
                heapq.heappop(open_f)
            while open_b and closed_b[open_b[0][3]]:
                heapq.heappop(open_b)
            if not open_f or not open_b:
                break
            top_f, top_b = open_f[0][0], open_b[0][0]
            if mu <= min(top_f, top_b) + 1e-12:
                break
            forward = top_f <= top_b
            heap = open_f if forward else open_b
            g_own = gf if forward else gb
            g_oth = gb if forward else gf
            closed_own = closed_f if forward else closed_b
            came = cf if forward else cb
            target = goal if forward else start
            tx, ty = (gx, gy) if forward else (sx, sy)

            _, _, _, u = heapq.heappop(heap)
            if closed_own[u]:
                continue
            closed_own[u] = 1
            yield Event("expand", u, value=g_own[u])
            if g_oth[u] < INF:
                cand = g_own[u] + g_oth[u]
                if cand < mu:
                    mu, meet = cand, u
            if u == target:
                continue
            ux, uy = grid.pos(u)
            gu = g_own[u]
            wu = grid.weight[u]
            for v, c in grid.neighbors(u):
                if closed_own[v]:
                    continue
                vx, vy = grid.pos(v)
                if forward:
                    step = c                       # cost of entering v
                else:
                    # backward wave: g_b[v] is the cost of v -> u -> goal, so we
                    # need the *reversed* edge cost (terrain is directional).
                    base = SQRT2 if (vx != ux and vy != uy) else 1.0
                    step = base * wu
                ng = gu + step
                if ng < g_own[v] - 1e-12:
                    g_own[v] = ng
                    came[v] = u
                    cnt += 1
                    heapq.heappush(heap, (ng + hf(vx, vy, tx, ty), cnt, cnt, v))
                    yield Event("frontier", v)
                    if g_oth[v] < INF:
                        cand = ng + g_oth[v]
                        if cand < mu:
                            mu, meet = cand, v

        if meet == -1:
            yield Event("info", text="No path exists (start and goal are disconnected).")
            return
        # g values only ever decrease, so re-evaluate the meeting node with the
        # final pointers: this keeps the reported cost == the real path cost.
        mu = gf[meet] + gb[meet]
        left = reconstruct(cf, meet)
        right = []
        node = cb[meet]
        while node != -1:
            right.append(node)
            node = cb[node]
        path = tuple(left) + tuple(right)
        yield Event("path", path=path, value=mu)


class ThetaStar(Algorithm):
    key = "theta"
    name = "Theta* (any-angle)"
    tag = "any-angle"
    blurb = ("A* with line-of-sight parent shortcuts: paths are straight segments, "
             "not staircase grid moves. Near-optimal in the continuous plane.")
    any_angle = True

    def search(self, grid, opts: Options) -> Iterator[Event]:
        n = grid.size
        start, goal = grid.start, grid.goal
        scale = grid.min_weight
        h = make_heuristic("euclidean", False, scale)
        sx, sy = grid.pos(start)
        gx, gy = grid.pos(goal)
        g = [INF] * n
        parent = [-1] * n
        closed = bytearray(n)
        g[start] = 0.0
        parent[start] = start
        cnt = 0
        heap = [(h(sx, sy, gx, gy), 0.0, cnt, start)]
        yield Event("frontier", start)
        yield Event("info", text="Theta*: any-angle search, cost = euclid x mean terrain on the ray")
        while heap:
            _, _, _, u = heapq.heappop(heap)
            if closed[u]:
                continue
            closed[u] = 1
            yield Event("expand", u, value=g[u])
            if u == goal:
                path = [u]
                while parent[u] != u:
                    u = parent[u]
                    path.append(u)
                path.reverse()
                cost = sum(grid.line_cost(a, b) for a, b in zip(path, path[1:]))
                yield Event("path", path=tuple(path), value=cost)
                return
            p = parent[u]
            gp = g[p]
            for v, c in grid.neighbors(u):
                if closed[v]:
                    continue
                if p != u and grid.line_of_sight(p, v):
                    ng = gp + grid.line_cost(p, v)
                    np = p
                    ray = grid.line_cells(p, v)
                    for cell in ray[1:-1:2]:
                        yield Event("scan", cell)
                else:
                    ng = g[u] + c
                    np = u
                if ng < g[v] - 1e-9:
                    g[v] = ng
                    parent[v] = np
                    vx, vy = grid.pos(v)
                    cnt += 1
                    heapq.heappush(heap, (ng + h(vx, vy, gx, gy), ng, cnt, v))
                    yield Event("frontier", v)
        yield Event("info", text="No path exists (start and goal are disconnected).")
