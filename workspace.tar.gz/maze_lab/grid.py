"""Grid model: walls, weighted terrain, connectivity rules and line-of-sight.

The grid is stored flat (index = y * cols + x) for speed.  Neighbour lists are
cached and invalidated whenever the topology changes, which makes the inner
loops of the search algorithms allocation-free.
"""
from __future__ import annotations

import math
from typing import Iterable, Iterator

SQRT2 = math.sqrt(2.0)
INF = float("inf")

DIRS4 = ((1, 0), (-1, 0), (0, 1), (0, -1))
DIRS8 = DIRS4 + ((1, 1), (1, -1), (-1, 1), (-1, -1))


class Grid:
    """A weighted 4/8-connected occupancy grid."""

    def __init__(self, cols: int = 41, rows: int = 31,
                 diagonal: bool = False, corner_cutting: bool = False):
        self.diagonal = diagonal
        self.corner_cutting = corner_cutting
        self.cols = 0
        self.rows = 0
        self.walls = bytearray()
        self.weight: list[float] = []
        self.start = 0
        self.goal = 0
        self._nbr: dict[int, list[tuple[int, float]]] = {}
        self._min_weight = 1.0
        self.version = 0
        self.resize(cols, rows)

    # ------------------------------------------------------------------ setup
    def resize(self, cols: int, rows: int) -> None:
        cols = max(7, int(cols) | 1)          # keep odd sizes for maze carving
        rows = max(7, int(rows) | 1)
        self.cols, self.rows = cols, rows
        n = cols * rows
        self.walls = bytearray(n)
        self.weight = [1.0] * n
        self.start = self.idx(1, 1)
        self.goal = self.idx(cols - 2, rows - 2)
        self.invalidate()

    @property
    def size(self) -> int:
        return self.cols * self.rows

    def invalidate(self) -> None:
        self._nbr.clear()
        self._min_weight = min((w for i, w in enumerate(self.weight)
                                if not self.walls[i]), default=1.0)
        self.version += 1

    def clear(self, keep_border: bool = True) -> None:
        self.walls = bytearray(self.size)
        self.weight = [1.0] * self.size
        if keep_border:
            for x in range(self.cols):
                self.walls[self.idx(x, 0)] = 1
                self.walls[self.idx(x, self.rows - 1)] = 1
            for y in range(self.rows):
                self.walls[self.idx(0, y)] = 1
                self.walls[self.idx(self.cols - 1, y)] = 1
        self.invalidate()

    def copy(self) -> "Grid":
        g = Grid(self.cols, self.rows, self.diagonal, self.corner_cutting)
        g.walls = bytearray(self.walls)
        g.weight = list(self.weight)
        g.start, g.goal = self.start, self.goal
        g.invalidate()
        return g

    # ------------------------------------------------------------- accessors
    def idx(self, x: int, y: int) -> int:
        return y * self.cols + x

    def pos(self, i: int) -> tuple[int, int]:
        return i % self.cols, i // self.cols

    def inside(self, x: int, y: int) -> bool:
        return 0 <= x < self.cols and 0 <= y < self.rows

    def blocked(self, x: int, y: int) -> bool:
        """Outside the grid counts as blocked (simplifies JPS / LOS code)."""
        return not (0 <= x < self.cols and 0 <= y < self.rows) or bool(self.walls[y * self.cols + x])

    def free(self, x: int, y: int) -> bool:
        return not self.blocked(x, y)

    def set_wall(self, i: int, value: bool = True) -> None:
        v = 1 if value else 0
        if self.walls[i] != v:
            self.walls[i] = v
            self.invalidate()

    def set_weight(self, i: int, w: float) -> None:
        w = max(1.0, float(w))
        if self.weight[i] != w:
            self.weight[i] = w
            self.invalidate()

    @property
    def min_weight(self) -> float:
        return self._min_weight

    @property
    def has_weights(self) -> bool:
        return any(w > 1.0 for w in self.weight)

    # ------------------------------------------------------------- movement
    def neighbors(self, i: int) -> list[tuple[int, float]]:
        cached = self._nbr.get(i)
        if cached is not None:
            return cached
        cols = self.cols
        x, y = i % cols, i // cols
        out: list[tuple[int, float]] = []
        w = self.weight
        for dx, dy in DIRS4:
            nx, ny = x + dx, y + dy
            if self.free(nx, ny):
                j = ny * cols + nx
                out.append((j, w[j]))
        if self.diagonal:
            cc = self.corner_cutting
            for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                nx, ny = x + dx, y + dy
                if not self.free(nx, ny):
                    continue
                if not cc and (self.blocked(x + dx, y) or self.blocked(x, y + dy)):
                    continue
                j = ny * cols + nx
                out.append((j, SQRT2 * w[j]))
        self._nbr[i] = out
        return out

    def step_cost(self, i: int, j: int) -> float:
        xi, yi = self.pos(i)
        xj, yj = self.pos(j)
        base = SQRT2 if (xi != xj and yi != yj) else 1.0
        if self.blocked(xj, yj) or self.blocked(xi, yi):
            return INF
        return base * self.weight[j]

    def path_cost(self, path: Iterable[int]) -> float:
        path = list(path)
        return sum(self.step_cost(a, b) for a, b in zip(path, path[1:]))

    def path_length(self, path: Iterable[int]) -> float:
        """Geometric length (ignores terrain weight)."""
        path = list(path)
        total = 0.0
        for a, b in zip(path, path[1:]):
            ax, ay = self.pos(a)
            bx, by = self.pos(b)
            total += math.hypot(bx - ax, by - ay)
        return total

    # ------------------------------------------------------- line of sight
    def line_cells(self, a: int, b: int) -> list[int]:
        """Supercover rasterisation of segment a->b (every touched cell)."""
        x0, y0 = self.pos(a)
        x1, y1 = self.pos(b)
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x1 > x0 else -1
        sy = 1 if y1 > y0 else -1
        x, y = x0, y0
        cells = [y0 * self.cols + x0]
        err = dx - dy
        dx2, dy2 = dx * 2, dy * 2
        while x != x1 or y != y1:
            if err > 0:
                x += sx
                err -= dy2
            elif err < 0:
                y += sy
                err += dx2
            else:                       # exactly through a lattice corner
                x += sx
                y += sy
                err += dx2 - dy2
            cells.append(y * self.cols + x)
        return cells

    def line_of_sight(self, a: int, b: int) -> bool:
        x0, y0 = self.pos(a)
        x1, y1 = self.pos(b)
        dx, dy = abs(x1 - x0), abs(y1 - y0)
        sx = 1 if x1 > x0 else -1
        sy = 1 if y1 > y0 else -1
        x, y = x0, y0
        err = dx - dy
        dx2, dy2 = dx * 2, dy * 2
        while x != x1 or y != y1:
            if err > 0:
                x += sx
                err -= dy2
            elif err < 0:
                y += sy
                err += dx2
            else:
                if not self.corner_cutting and (self.blocked(x + sx, y) or self.blocked(x, y + sy)):
                    return False
                x += sx
                y += sy
                err += dx2 - dy2
            if self.blocked(x, y):
                return False
        return True

    def line_cost(self, a: int, b: int) -> float:
        """Cost of an any-angle segment: length x mean terrain weight."""
        cells = self.line_cells(a, b)
        ax, ay = self.pos(a)
        bx, by = self.pos(b)
        length = math.hypot(bx - ax, by - ay)
        if len(cells) < 2:
            return 0.0
        mean = sum(self.weight[c] for c in cells[1:]) / (len(cells) - 1)
        return length * mean

    # -------------------------------------------------------------- helpers
    def free_cells(self) -> Iterator[int]:
        return (i for i, w in enumerate(self.walls) if not w)

    def reachable(self, source: int | None = None) -> set[int]:
        from collections import deque
        src = self.start if source is None else source
        seen = {src}
        dq = deque([src])
        while dq:
            u = dq.popleft()
            for v, _ in self.neighbors(u):
                if v not in seen:
                    seen.add(v)
                    dq.append(v)
        return seen

    def ensure_solvable(self) -> None:
        """Guarantee start/goal are open and in the same component."""
        self.set_wall(self.start, False)
        self.set_wall(self.goal, False)
        if self.goal in self.reachable():
            return
        # carve an L corridor from the goal until we touch the start component
        reach = self.reachable()
        gx, gy = self.pos(self.goal)
        sx, sy = self.pos(self.start)
        x, y = gx, gy
        while y != sy:
            y += 1 if sy > y else -1
            i = self.idx(x, y)
            self.set_wall(i, False)
            if i in reach:
                return
        while x != sx:
            x += 1 if sx > x else -1
            i = self.idx(x, y)
            self.set_wall(i, False)
            if i in reach:
                return
