#!/usr/bin/env python3
"""Maze Lab - entry point.

    python main.py                     # launch the pygame playground
    python main.py --maze cave -d -w   # 8-way cave with weighted terrain
    python main.py --algo jps --instant
    python main.py --benchmark         # headless comparison table, no window
    python main.py --selftest          # run the correctness suite
    python main.py --demo              # render docs/preview.png + docs/demo.gif
"""
from __future__ import annotations

import argparse
import os
import sys


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Maze Lab - advanced pygame pathfinding visualiser")
    p.add_argument("--algo", default="astar",
                   help="bfs dfs dijkstra astar wastar biastar jps theta dstar aco")
    p.add_argument("--maze", default="braid",
                   help="backtracker prim kruskal division braid cave rooms terrain scatter empty")
    p.add_argument("--size", type=int, default=41, help="grid width in cells (odd)")
    p.add_argument("-d", "--diagonal", action="store_true", help="8-way movement")
    p.add_argument("-w", "--weighted", action="store_true", help="weighted terrain")
    p.add_argument("--instant", action="store_true", help="no animation, solve immediately")
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--width", type=int, default=1400)
    p.add_argument("--height", type=int, default=880)
    p.add_argument("--benchmark", action="store_true", help="headless benchmark, print a table")
    p.add_argument("--selftest", action="store_true", help="run the unittest suite")
    p.add_argument("--demo", action="store_true", help="render preview image + animated GIF")
    return p.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)

    if args.selftest:
        import unittest
        suite = unittest.defaultTestLoader.discover("tests")
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        return 0 if result.wasSuccessful() else 1

    if args.demo:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        from demo import render_demo
        render_demo()
        return 0

    if args.benchmark:
        os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
        os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
        from maze_lab.app import App
        from maze_lab import mazegen
        app = App(headless=True, seed=args.seed or 1)
        app.grid.resize(args.size, max(11, int(args.size * 0.72) | 1))
        app.grid.diagonal = args.diagonal
        app.weighted = args.weighted
        app.weight_btn.active = args.weighted
        app.diag_btn.active = args.diagonal
        app.gen_kind = args.maze
        app.new_maze()
        app.benchmark()
        rows = sorted(app.compare_results, key=lambda r: r["exp"])
        print(f"\n{app.grid.cols}x{app.grid.rows} | {args.maze} | "
              f"{'8-way' if args.diagonal else '4-way'} | "
              f"{'weighted' if args.weighted else 'uniform'}\n")
        print(f"{'algorithm':<28}{'expanded':>10}{'scans':>9}{'cost':>10}{'cells':>7}{'ms':>9}")
        print("-" * 73)
        for r in rows:
            cost = f"{r['cost']:.2f}" if r["cost"] is not None else "no path"
            print(f"{r['name']:<28}{r['exp']:>10,}{r['scans']:>9,}{cost:>10}"
                  f"{r['cells']:>7}{r['ms']:>9.1f}")
        print()
        return 0

    from maze_lab.app import App
    from maze_lab.algorithms import REGISTRY
    app = App(size=(args.width, args.height), seed=args.seed)
    app.grid.diagonal = args.diagonal
    app.diag_btn.active = args.diagonal
    app.weighted = args.weighted
    app.weight_btn.active = args.weighted
    app.gen_choice.set(args.maze)
    app.gen_kind = args.maze
    app.size_slider.set(args.size)
    app.new_maze()
    if args.algo in REGISTRY:
        app.select_algorithm(args.algo)
    if args.instant:
        app.speed_slider.set(100)
        app.speed = 100
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
