"""Jump Point Search - online symmetry breaking for uniform-cost grids.

Two flavours live here:

* JPS8 (Harabor & Grastien, AAAI 2011) for 8-connected grids.  Straight and
  diagonal "jumps" skip symmetric cells; only obstacle corners (forced
  neighbours) and the goal ever enter the open list.
* JPS4 (Johannes Baum, arXiv:2501.14816, 2025) for 4-connected grids, where the
  original pruning rules are *not* sound.  It uses a horizontal-first canonical
  ordering: horizontal moves are never pruned, vertical moves are compressed
  into jumps that stop at forced neighbours (obstacle corners) or the goal.

Both return exactly the same optimal cost as A*/Dijkstra, usually with far
fewer node expansions.  Terrain weights are not supported (uniform cost only).
"""
from __future__ import annotations

import heapq
from typing import Iterator

from ..grid import INF, SQRT2
from ..heuristics import make_heuristic
from .base import Algorithm, Event, Options


class JumpPointSearch(Algorithm):
    key = "jps"
    name = "Jump Point Search"
    tag = "optimal / fast"
    blurb = ("Symmetry breaking: JPS8 on 8-way grids, JPS4 (horizontal-first canonical "
             "ordering) on 4-way grids. Same optimal cost as A*, far fewer expansions.")
    weighted_ok = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        cols, rows = grid.cols, grid.rows
        walls = grid.walls
        diagonal = grid.diagonal
        start, goal = grid.start, grid.goal
        sx, sy = start % cols, start // cols
        gx, gy = goal % cols, goal // cols
        h = make_heuristic("octile" if diagonal else "manhattan", diagonal, 1.0)
        scan: list[int] = []

        def blocked(x: int, y: int) -> bool:
            return not (0 <= x < cols and 0 <= y < rows) or walls[y * cols + x] == 1

        # =====================================================================
        # JPS8 - 8-connected, no corner cutting
        # =====================================================================
        def jump_straight8(x: int, y: int, dx: int, dy: int) -> int:
            while True:
                nx, ny = x + dx, y + dy
                if blocked(nx, ny):
                    return -1
                scan.append(ny * cols + nx)
                if nx == gx and ny == gy:
                    return ny * cols + nx
                if dx:
                    if ((blocked(x, ny + 1) and not blocked(nx, ny + 1)) or
                            (blocked(x, ny - 1) and not blocked(nx, ny - 1))):
                        return ny * cols + nx
                else:
                    if ((blocked(nx + 1, y) and not blocked(nx + 1, ny)) or
                            (blocked(nx - 1, y) and not blocked(nx - 1, ny))):
                        return ny * cols + nx
                x, y = nx, ny

        def jump_diag8(x: int, y: int, dx: int, dy: int) -> int:
            while True:
                nx, ny = x + dx, y + dy
                if blocked(nx, ny) or blocked(nx, y) or blocked(x, ny):
                    return -1
                scan.append(ny * cols + nx)
                if nx == gx and ny == gy:
                    return ny * cols + nx
                if blocked(nx - dx, ny) or blocked(nx, ny - dy):
                    return ny * cols + nx
                if (jump_straight8(nx, ny, dx, 0) >= 0 or
                        jump_straight8(nx, ny, 0, dy) >= 0):
                    return ny * cols + nx
                x, y = nx, ny

        def directions8(u: int, parent: int) -> list[tuple[int, int]]:
            x, y = u % cols, u // cols
            if parent < 0:
                return [(1, 0), (-1, 0), (0, 1), (0, -1),
                        (1, 1), (1, -1), (-1, 1), (-1, -1)]
            px, py = parent % cols, parent // cols
            dx = (x > px) - (x < px)
            dy = (y > py) - (y < py)
            if dx and dy:
                out = [(dx, 0), (0, dy), (dx, dy)]
                if blocked(x - dx, y):
                    out.append((-dx, dy))
                if blocked(x, y - dy):
                    out.append((dx, -dy))
                return out
            if dx:
                out = [(dx, 0)]
                for s in (1, -1):
                    if blocked(x - dx, y + s) and not blocked(x, y + s):
                        out.append((0, s))
                        out.append((dx, s))
                return out
            out = [(0, dy)]
            for s in (1, -1):
                if blocked(x + s, y - dy) and not blocked(x + s, y):
                    out.append((s, 0))
                    out.append((s, dy))
            return out

        # =====================================================================
        # JPS4 - 4-connected, horizontal-first canonical ordering
        # =====================================================================
        def jump4(x: int, y: int, dx: int, dy: int) -> int:
            while True:
                nx, ny = x + dx, y + dy
                if blocked(nx, ny):
                    return -1
                scan.append(ny * cols + nx)
                if dx:                       # horizontal: never compressed
                    return ny * cols + nx
                # vertical: stop at a forced neighbour (obstacle beside the parent)
                if ((blocked(x + 1, y) and not blocked(nx + 1, ny)) or
                        (blocked(x - 1, y) and not blocked(nx - 1, ny))):
                    return ny * cols + nx
                if nx == gx and ny == gy:
                    return ny * cols + nx
                x, y = nx, ny

        def directions4(u: int, parent: int) -> list[tuple[int, int]]:
            x, y = u % cols, u // cols
            if parent < 0:
                return [(1, 0), (-1, 0), (0, 1), (0, -1)]
            px, py = parent % cols, parent // cols
            dx = (x > px) - (x < px)
            dy = (y > py) - (y < py)
            if dx:                            # horizontal: everything but the parent
                out = [(dx, 0)]
                if not blocked(x, y + 1):
                    out.append((0, 1))
                if not blocked(x, y - 1):
                    out.append((0, -1))
                return out
            out = [(0, dy)]                   # vertical: only straight, unless forced
            for s in (1, -1):
                if blocked(x + s, y - dy) and not blocked(x + s, y):
                    out.append((s, 0))
            return out

        if diagonal:
            directions, do_jump = directions8, None

            def do_jump(x, y, dx, dy):        # noqa: F811
                return jump_diag8(x, y, dx, dy) if (dx and dy) else jump_straight8(x, y, dx, dy)
        else:
            directions, do_jump = directions4, jump4

        # ------------------------------------------------------------ A* core
        n = grid.size
        g = [INF] * n
        came = [-1] * n
        closed = bytearray(n)
        g[start] = 0.0
        cnt = 0
        heap = [(h(sx, sy, gx, gy), 0.0, cnt, start)]
        yield Event("frontier", start)
        yield Event("info", text=("JPS8: straight + diagonal jumps, forced neighbours at corners"
                                  if diagonal else
                                  "JPS4: horizontal-first canonical ordering (Baum 2025)"))
        if grid.has_weights:
            yield Event("info", text="JPS assumes uniform step cost - terrain weights are ignored.")
        queued = 0
        while heap:
            _, _, _, u = heapq.heappop(heap)
            if closed[u]:
                continue
            closed[u] = 1
            for cell in scan:
                yield Event("scan", cell)
            scan.clear()
            yield Event("expand", u, value=g[u])
            if u == goal:
                chain = [u]
                while came[u] != -1:
                    u = came[u]
                    chain.append(u)
                chain.reverse()
                full = _interpolate(chain, cols)
                yield Event("path", path=tuple(full), value=g[goal])
                yield Event("info", text=f"{'JPS8' if diagonal else 'JPS4'}: {queued} jump points "
                                         f"queued, {len(chain)} turning points on the path")
                return
            ux, uy = u % cols, u // cols
            gu = g[u]
            for dx, dy in directions(u, came[u]):
                nx, ny = ux + dx, uy + dy
                if blocked(nx, ny):
                    continue
                if dx and dy and (blocked(nx, uy) or blocked(ux, ny)):
                    continue
                v = do_jump(ux, uy, dx, dy)
                if v < 0:
                    continue
                vx, vy = v % cols, v // cols
                steps = max(abs(vx - ux), abs(vy - uy))
                cost = steps * (SQRT2 if (dx and dy) else 1.0)
                ng = gu + cost
                if ng < g[v] - 1e-12 and not closed[v]:
                    g[v] = ng
                    came[v] = u
                    cnt += 1
                    queued += 1
                    heapq.heappush(heap, (ng + h(vx, vy, gx, gy), ng, cnt, v))
                    yield Event("frontier", v)
        for cell in scan:
            yield Event("scan", cell)
        yield Event("info", text="No path exists (start and goal are disconnected).")


def _interpolate(chain: list[int], cols: int) -> list[int]:
    """Expand a jump-point chain into every cell it walks through."""
    if not chain:
        return []
    out = [chain[0]]
    for a, b in zip(chain, chain[1:]):
        ax, ay = a % cols, a // cols
        bx, by = b % cols, b // cols
        dx = (bx > ax) - (bx < ax)
        dy = (by > ay) - (by < ay)
        x, y = ax, ay
        while (x, y) != (bx, by):
            x += dx
            y += dy
            out.append(y * cols + x)
    return out
