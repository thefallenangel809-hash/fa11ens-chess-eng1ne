"""Ant Colony Optimisation - a stochastic metaheuristic, for contrast.

Not optimal and not complete, but a nice demonstration of emergent path
reinforcement: ants lay pheromone, good routes evaporate slower than they are
reinforced, and the colony converges on a short route.
"""
from __future__ import annotations

import math
import random
from typing import Iterator

from ..grid import INF
from ..heuristics import heuristic_for
from .base import Algorithm, Event, Options


class AntColony(Algorithm):
    key = "aco"
    name = "Ant Colony Optimisation"
    tag = "metaheuristic"
    blurb = ("Swarm search: pheromone x heuristic roulette-wheel walks, evaporation "
             "and elitist reinforcement. Approximate, but fun to watch converge.")
    optimal = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        rng = random.Random(opts.seed)
        n = grid.size
        alpha, beta, rho, Q = 1.0, 2.6, 0.12, 60.0
        tau = [1.0] * n
        hf = heuristic_for(grid, opts.heuristic)
        gx, gy = grid.pos(grid.goal)
        eta = [0.0] * n
        cols = grid.cols
        for i in range(n):
            if not grid.walls[i]:
                x, y = i % cols, i // cols
                eta[i] = 1.0 / (1.0 + hf(x, y, gx, gy))
        nbrs = {i: grid.neighbors(i) for i in range(n) if not grid.walls[i]}
        start, goal = grid.start, grid.goal
        best_path: tuple[int, ...] = ()
        best_cost = INF
        max_steps = 4 * n
        ants = max(4, opts.ants)
        iterations = max(1, opts.iterations)
        yield Event("info", text=f"ACO: {ants} ants x {iterations} iterations, "
                                 f"alpha={alpha} beta={beta} rho={rho}")

        for it in range(iterations):
            found: list[tuple[float, list[int]]] = []
            for _ in range(ants):
                path = [start]
                tabu = bytearray(n)
                tabu[start] = 1
                u = start
                cost = 0.0
                for _ in range(max_steps):
                    if u == goal:
                        break
                    choices = [(v, c) for v, c in nbrs.get(u, ()) if not tabu[v]]
                    if not choices:
                        if len(path) == 1:
                            break
                        path.pop()          # dead end -> backtrack
                        u = path[-1]
                        continue
                    weights = [(tau[v] ** alpha) * (eta[v] ** beta) for v, _ in choices]
                    total = sum(weights)
                    if total <= 0:
                        k = rng.randrange(len(choices))
                    else:
                        r = rng.random() * total
                        acc = 0.0
                        k = len(choices) - 1
                        for j, w in enumerate(weights):
                            acc += w
                            if acc >= r:
                                k = j
                                break
                    v, c = choices[k]
                    cost += c
                    tabu[v] = 1
                    path.append(v)
                    u = v
                    yield Event("expand", v, value=cost)
                if u == goal:
                    found.append((cost, path))
                    if cost < best_cost:
                        best_cost, best_path = cost, tuple(path)
                        yield Event("info", text=f"iteration {it + 1}: new best cost {best_cost:.2f} "
                                                 f"({len(best_path)} cells)")

            # ---- evaporation + deposition
            decay = 1.0 - rho
            for i in range(n):
                tau[i] *= decay
                if tau[i] < 0.01:
                    tau[i] = 0.01
            for cost, path in found:
                amount = Q / max(1e-6, cost)
                for node in path:
                    tau[node] += amount
            if best_path:
                elite = 3.0 * Q / max(1e-6, best_cost)
                for node in best_path:
                    tau[node] += elite
            peak = max(tau[i] for i in range(n) if not grid.walls[i])
            for i in range(n):
                if not grid.walls[i] and tau[i] > 0.05:
                    yield Event("pheromone", i, value=tau[i] / peak)
            yield Event("frontier", goal)

        if not best_path:
            yield Event("info", text="Colony never reached the goal - try more iterations.")
            return
        yield Event("path", path=best_path, value=best_cost)
