"""Algorithm plumbing: events, options, stats and the registry."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterator


@dataclass(slots=True)
class Event:
    """Something the visualiser should know about.

    kind: expand | frontier | scan | path | info | agent | wall | pheromone
    """
    kind: str
    node: int = -1
    path: tuple[int, ...] = ()
    text: str = ""
    value: float = 0.0
    flag: bool = False


@dataclass
class Options:
    heuristic: str = "auto"
    weight: float = 1.5          # epsilon for Weighted A*
    seed: int = 1234
    dynamic: bool = False        # D* Lite: moving obstacles while walking
    obstacle_rate: float = 0.35
    ants: int = 24
    iterations: int = 60
    max_expansions: int = 4_000_000


@dataclass
class Stats:
    expanded: int = 0
    discovered: int = 0
    scanned: int = 0
    frontier_peak: int = 0
    path_cost: float = 0.0
    path_nodes: int = 0
    path_length: float = 0.0
    seconds: float = 0.0
    extra: dict = field(default_factory=dict)

    def reset(self) -> None:
        self.expanded = self.discovered = self.scanned = self.frontier_peak = 0
        self.path_cost = self.path_length = 0.0
        self.path_nodes = 0
        self.seconds = 0.0
        self.extra.clear()


class Algorithm:
    key = "base"
    name = "Base"
    tag = ""
    blurb = ""
    optimal = True          # returns a minimum-cost path on its supported class
    weighted_ok = True      # handles terrain weights correctly
    any_angle = False
    incremental = False

    def search(self, grid, opts: Options) -> Iterator[Event]:
        raise NotImplementedError

    def __repr__(self) -> str:
        return f"<{self.name}>"


def reconstruct(came: list[int], node: int) -> tuple[int, ...]:
    path = [node]
    while came[node] != -1:
        node = came[node]
        path.append(node)
    path.reverse()
    return tuple(path)


REGISTRY: dict[str, Algorithm] = {}


def register(algo: Algorithm) -> Algorithm:
    REGISTRY[algo.key] = algo
    return algo
